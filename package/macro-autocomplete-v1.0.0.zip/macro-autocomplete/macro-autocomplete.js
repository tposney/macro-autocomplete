var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// src/lib/foundryCompletions.json
var foundryCompletions_default = {
  Dialog: {
    type: "class",
    detail: "Dialog",
    constructorDetail: "(data, options?) => Dialog",
    staticChildren: {
      defaultOptions: {
        type: "property",
        detail: "Dialog.Options"
      },
      confirm: {
        type: "method",
        detail: "(config?) => Promise<Yes | No | Dialog.OnReject<RejectClose, false>>",
        info: "A helper factory method to create simple confirmation dialog windows which consist of simple yes/no prompts.\nIf you require more flexibility, a custom Dialog instance is preferred."
      },
      prompt: {
        type: "method",
        detail: "(config) => Promise<Value | Dialog.OnReject<RejectClose, true>>",
        info: 'A helper factory method to display a basic "prompt" style Dialog with a single button'
      },
      wait: {
        type: "method",
        detail: "(data, options?, renderOptions?) => Promise<unknown>",
        info: "Wrap the Dialog with an enclosing Promise which resolves or rejects when the client makes a choice."
      }
    },
    instanceChildren: {
      data: {
        type: "property",
        detail: "Dialog.Data<JQuery | HTMLElement>"
      },
      title: {
        type: "property",
        detail: "string"
      },
      getData: {
        type: "method",
        detail: "(options?) => MaybePromise<object>"
      },
      activateListeners: {
        type: "method",
        detail: "(html) => void"
      },
      submit: {
        type: "method",
        detail: "(button, event?) => void",
        info: "Submit the Dialog by selecting one of its buttons"
      },
      close: {
        type: "method",
        detail: "(options?) => Promise<void>"
      }
    }
  },
  Item: {
    type: "class",
    detail: "Item",
    constructorDetail: "(data, context?) => Item",
    instancePath: "item",
    staticChildren: {
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<Item.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Item.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Item.Implementation>"
      }
    },
    instanceChildren: {
      actor: {
        type: "property",
        detail: "Actor.Implementation | null",
        info: "A convenience alias of Item#parent which is more semantically intuitive"
      },
      thumbnail: {
        type: "property",
        detail: "string",
        info: "Provide a thumbnail image path used to represent this document."
      },
      isOwned: {
        type: "property",
        detail: "boolean",
        info: "A convenience alias of Item#isEmbedded which is preserves legacy support"
      },
      transferredEffects: {
        type: "property",
        detail: "ActiveEffect.Implementation[]",
        info: "Return an array of the Active Effect instances which originated from this Item.\nThe returned instances are the ActiveEffect instances which exist on the Item itself."
      },
      getRollData: {
        type: "method",
        detail: "() => AnyObject",
        info: "Prepare a data object which defines the data schema used by dice roll commands against this Item"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Hooks: {
    type: "class",
    detail: "Hooks",
    staticChildren: {
      events: {
        type: "property",
        detail: "Record<string, Hooks.HookedFunction[]>",
        info: "A mapping of hook events which have functions registered to them."
      },
      on: {
        type: "method",
        detail: "(hook, fn, options?) => number"
      },
      once: {
        type: "method",
        detail: "(hook, fn, options?) => number"
      },
      off: {
        type: "method",
        detail: "(hook, fn, options?) => void"
      },
      callAll: {
        type: "method",
        detail: "(hook, args) => true"
      },
      call: {
        type: "method",
        detail: "(hook, args) => boolean"
      },
      onError: {
        type: "method",
        detail: "(location, error, { msg, notify, log, ...data }?) => void",
        info: "Notify subscribers that an error has occurred within foundry."
      }
    }
  },
  Canvas: {
    type: "class",
    detail: "Canvas",
    constructorDetail: "() => Canvas",
    staticChildren: {
      layers: {
        type: "property",
        detail: "typeof CONFIG.Canvas.layers",
        info: "A mapping of named CanvasLayer classes which defines the layers which comprise the Scene."
      },
      getSceneManager: {
        type: "method",
        detail: "(scene) => foundry.canvas.SceneManager.Any | null",
        info: "Create a SceneManager instance used for this Scene, if any."
      },
      clearContainer: {
        type: "method",
        detail: "(displayObject, destroy?) => void",
        info: "Remove all children of the display object and call one cleaning method:\nclean first, then tearDown, and destroy if no cleaning method is found."
      },
      getRenderTexture: {
        type: "method",
        detail: "(options?) => PIXI.RenderTexture",
        info: "Get a texture with the required configuration and clear color."
      }
    },
    instanceChildren: {
      blurFilters: {
        type: "property",
        detail: "Set<PIXI.BlurFilter>",
        info: 'A set of blur filter instances which are modified by the zoom level and the "soft shadows" setting'
      },
      currentMouseManager: {
        type: "property",
        detail: "MouseInteractionManager<PIXI.Container> | null",
        info: "A reference to the MouseInteractionManager that is currently controlling pointer-based interaction, or null."
      },
      loadTexturesOptions: {
        type: "property",
        detail: "{ expireCache: boolean; additionalSources: string[] }",
        info: "Configure options passed to the texture loaded for the Scene.\nThis object can be configured during the canvasInit hook before textures have been loaded."
      },
      visibilityOptions: {
        type: "property",
        detail: "{ persistentVision: boolean }",
        info: "Configure options used by the visibility framework for special effects\nThis object can be configured during the canvasInit hook before visibility is initialized."
      },
      blurOptions: {
        type: "property",
        detail: "| { enabled: boolean; blurClass: typeof PIXI.BlurFilter; strength: number; passes: number; kernels: number; } | undefined",
        info: "Configure options passed to initialize blur for the Scene and override normal behavior.\nThis object can be configured during the canvasInit hook before blur is initialized."
      },
      sceneTextures: {
        type: "property",
        detail: "{ background?: string; foreground?: string; fogOverlay?: string }",
        info: "Configure the Textures to apply to the Scene.\nTextures registered here will be automatically loaded as part of the TextureLoader.loadSceneTextures workflow.\nTextures which need to be loaded should be "
      },
      fps: {
        type: "property",
        detail: '{ /** @defaultValue `0` */ average: number; /** @defaultValue `[]` */ values: number[]; /** @defaultValue `0` */ render: number; /** @defaultValue `document.getElementById("fps")` */ element: HTMLElement; }',
        info: "Record framerate performance data"
      },
      mouseInteractionManager: {
        type: "property",
        detail: "MouseInteractionManager<PIXI.Container> | undefined",
        info: "The singleton interaction manager instance which handles mouse interaction on the Canvas."
      },
      performance: {
        type: "property",
        detail: "Canvas.PerformanceSettings | undefined",
        info: "Configured performance settings which affect the behavior of the Canvas and its renderer."
      },
      supported: {
        type: "property",
        detail: "Canvas.SupportedComponents",
        info: "A list of supported webGL capabilities and limitations."
      },
      photosensitiveMode: {
        type: "property",
        detail: "boolean",
        info: "Is the photosensitive mode enabled?"
      },
      screenDimensions: {
        type: "property",
        detail: "[x: number, y: number]",
        info: "The renderer screen dimensions."
      },
      loading: {
        type: "property",
        detail: "boolean",
        info: "A flag to indicate whether a new Scene is currently being drawn."
      },
      initializing: {
        type: "property",
        detail: "Promise<void> | null",
        info: "A promise that resolves when the canvas is first initialized and ready."
      },
      app: {
        type: "property",
        detail: "PIXI.Application<HTMLCanvasElement> | undefined",
        info: "The singleton PIXI.Application instance rendered on the Canvas."
      },
      stage: {
        type: "property",
        detail: "PIXI.Container | undefined",
        info: "The primary stage container of the PIXI.Application."
      },
      rendered: {
        type: "property",
        detail: "groups.RenderedCanvasGroup",
        info: "The rendered canvas group which render the environment canvas group and the interface canvas group."
      },
      edges: {
        type: "property",
        detail: "foundry.canvas.geometry.edges.CanvasEdges",
        info: "A singleton CanvasEdges instance."
      },
      fog: {
        type: "property",
        detail: "FixedInstanceType<typeof CONFIG.Canvas.fogManager>",
        info: "The singleton FogManager instance."
      },
      perception: {
        type: "property",
        detail: "PerceptionManager",
        info: "A perception manager interface for batching lighting, sight, and sound updates"
      },
      environment: {
        type: "property",
        detail: "groups.EnvironmentCanvasGroup",
        info: "The environment canvas group which render the primary canvas group and the effects canvas group."
      },
      primary: {
        type: "property",
        detail: "groups.PrimaryCanvasGroup | undefined",
        info: "The primary Canvas group which generally contains tangible physical objects which exist within the Scene.\nThis group is a  which is rendered to the Scene as a .\nThis allows the rendered result of the "
      },
      effects: {
        type: "property",
        detail: "groups.EffectsCanvasGroup | undefined",
        info: "The effects Canvas group which modifies the result of the  by adding special effects.\nThis includes lighting, vision, fog of war and related animations."
      },
      visibility: {
        type: "property",
        detail: "groups.CanvasVisibility",
        info: "The visibility Canvas group which handles the fog of war overlay by consolidating multiple render textures,\nand applying a filter with special effects and blur."
      },
      interface: {
        type: "property",
        detail: "groups.InterfaceCanvasGroup | undefined",
        info: "The interface Canvas group which is rendered above other groups and contains all interactive elements.\nThe various  instances of the interface group provide different control sets for\ninteracting with"
      },
      overlay: {
        type: "property",
        detail: "groups.OverlayCanvasGroup",
        info: "The overlay Canvas group which is rendered above other groups and contains elements not bound to stage transform."
      },
      hud: {
        type: "property",
        detail: "foundry.applications.hud.HeadsUpDisplayContainer | undefined",
        info: "The singleton HeadsUpDisplay container which overlays HTML rendering on top of this Canvas."
      },
      mousePosition: {
        type: "property",
        detail: "PIXI.Point",
        info: "Position of the mouse on stage."
      },
      forceSnapVertices: {
        type: "property",
        detail: "boolean",
        info: "Force snapping to grid vertices?"
      },
      initialized: {
        type: "property",
        detail: "boolean",
        info: "A flag for whether the game Canvas is fully initialized and ready for additional content to be drawn."
      },
      scene: {
        type: "property",
        detail: "Scene.Stored | null",
        info: "A reference to the currently displayed Scene document, or null if the Canvas is currently blank."
      },
      manager: {
        type: "property",
        detail: "foundry.canvas.SceneManager | null",
        info: "A SceneManager instance which adds behaviors to this Scene, or null if there is no manager."
      },
      dimensions: {
        type: "property",
        detail: "Canvas.Dimensions | null",
        info: "The current pixel dimensions of the displayed Scene, or null if the Canvas is blank."
      },
      grid: {
        type: "property",
        detail: "foundry.grid.BaseGrid | null",
        info: "A reference to the grid of the currently displayed Scene document, or null if the Canvas is currently blank."
      },
      ready: {
        type: "property",
        detail: "boolean",
        info: "A flag for whether the game Canvas is ready to be used. False if the canvas is not yet drawn, true otherwise."
      },
      colors: {
        type: "property",
        detail: 'this["environment"]["colors"]',
        info: "The colors bound to this scene and handled by the color manager."
      },
      masks: {
        type: "property",
        detail: "PIXI.Container",
        info: "Shortcut to get the masks container from HiddenCanvasGroup."
      },
      id: {
        type: "property",
        detail: "string | null",
        info: "The id of the currently displayed Scene."
      },
      layers: {
        type: "property",
        detail: "layers.CanvasLayer[]",
        info: "An Array of all CanvasLayer instances which are active on the Canvas board"
      },
      activeLayer: {
        type: "property",
        detail: "layers.CanvasLayer | null",
        info: "Return a reference to the active Canvas Layer"
      },
      darknessLevel: {
        type: "property",
        detail: "number",
        info: "The currently displayed darkness level, which may override the saved Scene value."
      },
      initialize: {
        type: "method",
        detail: "() => void",
        info: "Initialize the Canvas by creating the HTML element and PIXI application.\nThis step should only ever be performed once per client session.\nSubsequent requests to reset the canvas should go through Canv"
      },
      snapshot: {
        type: "property",
        detail: "foundry.canvas.FramebufferSnapshot"
      },
      draw: {
        type: "method",
        detail: "(scene?) => Promise<this>",
        info: "Draw the game canvas."
      },
      tearDown: {
        type: "method",
        detail: "() => Promise<void>",
        info: "When re-drawing the canvas, first tear down or discontinue some existing processes"
      },
      getGLParameter: {
        type: "method",
        detail: "(parameter) => unknown",
        info: "Get the value of a GL parameter"
      },
      initializeCanvasPosition: {
        type: "method",
        detail: "() => void",
        info: "Initialize the starting view of the canvas stage\nIf we are re-drawing a scene which was previously rendered, restore the prior view position\nOtherwise set the view to the top-left corner of the scene "
      },
      weather: {
        type: "property",
        detail: "layers.WeatherEffects"
      },
      drawings: {
        type: "property",
        detail: "layers.DrawingsLayer"
      },
      templates: {
        type: "property",
        detail: "layers.TemplateLayer"
      },
      tiles: {
        type: "property",
        detail: "layers.TilesLayer"
      },
      walls: {
        type: "property",
        detail: "layers.WallsLayer"
      },
      tokens: {
        type: "property",
        detail: "layers.TokenLayer"
      },
      sounds: {
        type: "property",
        detail: "layers.SoundsLayer"
      },
      lighting: {
        type: "property",
        detail: "layers.LightingLayer"
      },
      notes: {
        type: "property",
        detail: "layers.NotesLayer"
      },
      regions: {
        type: "property",
        detail: "layers.RegionLayer"
      },
      controls: {
        type: "property",
        detail: "layers.ControlsLayer"
      },
      getLayerByEmbeddedName: {
        type: "method",
        detail: "(embeddedName) => T extends keyof EmbeddedEntityNameToLayerMap ? Exclude<EmbeddedEntityNameToLayerMap[T], undefined> | null : null",
        info: "Given an embedded object name, get the canvas layer for that object"
      },
      getCollectionLayer: {
        type: "method",
        detail: "(collectionName) => T extends keyof CollectionNameToLayerMap ? Exclude<CollectionNameToLayerMap[T], undefined> : undefined",
        info: "Get the InteractionLayer of the canvas which manages Documents of a certain collection within the Scene."
      },
      activateFPSMeter: {
        type: "method",
        detail: "() => void",
        info: "Activate framerate tracking by adding an HTML element to the display and refreshing it every frame."
      },
      deactivateFPSMeter: {
        type: "method",
        detail: "() => void",
        info: "Deactivate framerate tracking by canceling ticker updates and removing the HTML element."
      },
      pan: {
        type: "method",
        detail: "({ x, y, scale }?) => void",
        info: "Pan the canvas to a certain \\{x,y\\} coordinate and a certain zoom level"
      },
      animatePan: {
        type: "method",
        detail: "(view) => ReturnType<typeof CanvasAnimation.animate>",
        info: "Animate panning the canvas to a certain destination coordinate and zoom scale\nCustomize the animation speed with additional options\nReturns a Promise which is resolved once the animation has completed"
      },
      recenter: {
        type: "method",
        detail: '(initial?) => ReturnType<this["animatePan"]>',
        info: "Recenter the canvas with a pan animation that ends in the center of the canvas rectangle."
      },
      highlightObjects: {
        type: "method",
        detail: "(active) => void",
        info: "Highlight objects on any layers which are visible"
      },
      ping: {
        type: "method",
        detail: "(origin, options?) => Promise<boolean>",
        info: "Displays a Ping both locally and on other connected client, following these rules:\n1) Displays on the current canvas Scene\n2) If ALT is held, becomes an ALERT ping\n3) Else if the user is GM and SHIFT "
      },
      createBlurFilter: {
        type: "method",
        detail: "(blurStrength?, blurQuality?) => PIXI.BlurFilter",
        info: "Create a BlurFilter instance and register it to the array for updates when the zoom level changes."
      },
      addBlurFilter: {
        type: "method",
        detail: "(filter) => PIXI.BlurFilter",
        info: "Add a filter to the blur filter list. The filter must have the blur property"
      },
      updateBlur: {
        type: "method",
        detail: "(strength?) => void",
        info: "Update the blur strength depending on the scale of the canvas stage"
      },
      clientCoordinatesFromCanvas: {
        type: "method",
        detail: "(origin) => Canvas.Point",
        info: "Convert canvas coordinates to the client's viewport."
      },
      canvasCoordinatesFromClient: {
        type: "method",
        detail: "(origin) => Canvas.Point",
        info: "Convert client viewport coordinates to canvas coordinates."
      },
      isOffscreen: {
        type: "method",
        detail: "(position) => boolean",
        info: "Determine whether given canvas coordinates are off-screen."
      },
      pendingRenderFlags: {
        type: "property",
        detail: "Canvas.PendingRenderFlags",
        info: "Track objects which have pending render flags."
      },
      addPendingOperation: {
        type: "method",
        detail: "(name, fn, scope, args) => void"
      },
      triggerPendingOperations: {
        type: "method",
        detail: "() => void"
      },
      pendingOperations: {
        type: "property",
        detail: "[]"
      },
      colorManager: {
        type: "property",
        detail: 'this["environment"]'
      }
    }
  },
  Token: {
    type: "class",
    detail: "Token",
    instancePath: "token",
    staticChildren: {
      embeddedName: {
        type: "property",
        detail: '"Token"'
      },
      RENDER_FLAGS: {
        type: "property",
        detail: "Token.RENDER_FLAGS"
      }
    },
    instanceChildren: {
      renderFlags: {
        type: "property",
        detail: "RenderFlags<Token.RENDER_FLAGS>"
      },
      controlIcon: {
        type: "property",
        detail: "null"
      },
      shape: {
        type: "property",
        detail: "PIXI.Rectangle | PIXI.Polygon | undefined",
        info: "The shape of this token."
      },
      detectionFilter: {
        type: "property",
        detail: "PIXI.Filter | null",
        info: "Defines the filter to use for detection."
      },
      border: {
        type: "property",
        detail: "PIXI.Graphics | undefined",
        info: "A Graphics instance which renders the border frame for this Token inside the GridLayer."
      },
      bars: {
        type: "property",
        detail: "Token.Bars | undefined",
        info: "The attribute bars of this Token."
      },
      tooltip: {
        type: "property",
        detail: "PreciseText | undefined",
        info: "The tooltip text of this Token, which contains its elevation."
      },
      target: {
        type: "property",
        detail: "PIXI.Graphics | undefined",
        info: "The target marker, which indicates that this Token is targeted by this User or others."
      },
      nameplate: {
        type: "property",
        detail: "PreciseText | undefined",
        info: "The nameplate of this Token, which displays its name."
      },
      targeted: {
        type: "property",
        detail: "Set<User.Stored>",
        info: "Track the set of User documents which are currently targeting this Token"
      },
      mesh: {
        type: "property",
        detail: "PrimarySpriteMesh | undefined",
        info: "A reference to the SpriteMesh which displays this Token in the PrimaryCanvasGroup."
      },
      voidMesh: {
        type: "property",
        detail: "PIXI.Container | undefined",
        info: "Renders the mesh of this Token with ERASE blending in the Token."
      },
      detectionFilterMesh: {
        type: "property",
        detail: "PIXI.Container | undefined",
        info: "Renders the mesh of with the detection filter."
      },
      texture: {
        type: "property",
        detail: "PIXI.Texture | undefined",
        info: "The texture of this Token, which is used by its mesh."
      },
      vision: {
        type: "property",
        detail: "sources.PointVisionSource.Implementation | undefined",
        info: "A reference to the VisionSource object which defines this vision source area of effect"
      },
      light: {
        type: "property",
        detail: "sources.PointLightSource.Implementation | sources.PointDarknessSource.Implementation | undefined",
        info: "A reference to the LightSource object which defines this light source area of effect"
      },
      animationContexts: {
        type: "property",
        detail: "Map<string, Token.AnimationContext>",
        info: "The current animations of this Token."
      },
      ring: {
        type: "property",
        detail: "TokenRing.Implementation | null | undefined",
        info: "A TokenRing instance which is used if this Token applies a dynamic ring.\nThis property is null if the Token does not use a dynamic ring."
      },
      hasDynamicRing: {
        type: "property",
        detail: "boolean",
        info: "A convenience boolean to test whether the Token is using a dynamic ring."
      },
      actor: {
        type: "property",
        detail: 'TokenDocument.Implementation["actor"]',
        info: "A convenient reference to the Actor object associated with the Token embedded document."
      },
      observer: {
        type: "property",
        detail: "boolean",
        info: "A boolean flag for whether the current game User has observer permission for the Token"
      },
      name: {
        type: "property",
        detail: "string",
        info: "Convenience access to the token's nameplate string"
      },
      bounds: {
        type: "property",
        detail: "PIXI.Rectangle"
      },
      w: {
        type: "property",
        detail: "number",
        info: "Translate the token's grid width into a pixel width based on the canvas size"
      },
      h: {
        type: "property",
        detail: "number",
        info: "Translate the token's grid height into a pixel height based on the canvas size"
      },
      center: {
        type: "property",
        detail: "PIXI.Point",
        info: "The Token's current central position"
      },
      getMovementAdjustedPoint: {
        type: "method",
        detail: "(point, offsets?) => Canvas.Point",
        info: "The Token's central position, adjusted in each direction by one or zero pixels to offset it relative to walls."
      },
      sourceElement: {
        type: "property",
        detail: "PIXI.ImageSource | undefined",
        info: "The HTML source element for the primary Tile texture"
      },
      sourceId: {
        type: "property",
        detail: "string"
      },
      isVideo: {
        type: "property",
        detail: "boolean",
        info: "Does this Tile depict an animated video texture?"
      },
      inCombat: {
        type: "property",
        detail: "boolean",
        info: "An indicator for whether or not this token is currently involved in the active combat encounter."
      },
      combatant: {
        type: "property",
        detail: "Combatant.Stored",
        info: "Return a reference to a Combatant that represents this Token, if one is present in the current encounter."
      },
      isTargeted: {
        type: "property",
        detail: "boolean",
        info: "An indicator for whether the Token is currently targeted by the active game User"
      },
      detectionModes: {
        type: "property",
        detail: 'TokenDocument.Implementation["detectionModes"]',
        info: "Return a reference to the detection modes array."
      },
      isVisible: {
        type: "property",
        detail: "boolean",
        info: "Determine whether the Token is visible to the calling user's perspective.\nHidden Tokens are only displayed to GM Users.\nNon-hidden Tokens are always visible if Token Vision is not required.\nControlled"
      },
      animationName: {
        type: "property",
        detail: "string",
        info: "The animation name used for Token movement"
      },
      hasSight: {
        type: "property",
        detail: "boolean",
        info: "Test whether the Token has sight (or blindness) at any radius"
      },
      emitsDarkness: {
        type: "property",
        detail: "boolean",
        info: "Does this Ambient Light actively emit darkness given\nits properties and the current darkness level of the Scene?"
      },
      emitsLight: {
        type: "property",
        detail: "boolean",
        info: "Does this Ambient Light actively emit light given\nits properties and the current darkness level of the Scene?"
      },
      hasLimitedSourceAngle: {
        type: "property",
        detail: "boolean",
        info: "Test whether the Token uses a limited angle of vision or light emission."
      },
      dimRadius: {
        type: "property",
        detail: "number",
        info: "Translate the token's dim light distance in units into a radius in pixels."
      },
      brightRadius: {
        type: "property",
        detail: "number",
        info: "Translate the token's bright light distance in units into a radius in pixels."
      },
      radius: {
        type: "property",
        detail: "number",
        info: "The maximum radius in pixels of the light field"
      },
      lightPerceptionRange: {
        type: "property",
        detail: "number",
        info: "The range of this token's light perception in pixels."
      },
      sightRange: {
        type: "property",
        detail: "number",
        info: "Translate the token's vision range in units into a radius in pixels."
      },
      optimalSightRange: {
        type: "property",
        detail: "number",
        info: "Translate the token's maximum vision range that takes into account lights."
      },
      initializeSources: {
        type: "method",
        detail: "(options?) => void",
        info: "Update the light and vision source objects associated with this Token."
      },
      initializeLightSource: {
        type: "method",
        detail: "(options?) => void",
        info: "Update an emitted light source associated with this Token."
      },
      initializeVisionSource: {
        type: "method",
        detail: "(options?) => void",
        info: "Update the VisionSource instance associated with this Token."
      },
      clear: {
        type: "method",
        detail: "() => void"
      },
      drawBars: {
        type: "method",
        detail: "() => void",
        info: "Refresh the display of Token attribute bars, rendering its latest resource data.\nIf the bar attribute is valid (has a value and max), draw the bar. Otherwise hide it."
      },
      drawEffects: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Draw the active effects and overlay effect icons which are present upon the Token"
      },
      getRingColors: {
        type: "method",
        detail: "() => Token.RingColors",
        info: "Override ring colors for this particular Token instance."
      },
      getRingEffects: {
        type: "method",
        detail: "() => TokenRing.EFFECTS[]",
        info: "Apply additional ring effects for this particular Token instance.\nEffects are returned as an array of integers in ."
      },
      animate: {
        type: "method",
        detail: "(to, options?) => Promise<void>",
        info: "Animate from the old to the new state of this Token."
      },
      stopAnimation: {
        type: "method",
        detail: "(options?) => void",
        info: "Terminate animation of this particular Token."
      },
      checkCollision: {
        type: "method",
        detail: '(destination, options?) => PointSourcePolygon.TestCollision<Coalesce<Mode, "any">>',
        info: "Check for collision when attempting a move to a new position"
      },
      getSize: {
        type: "method",
        detail: "() => Token.Size",
        info: "Get the width and height of the Token in pixels."
      },
      getShape: {
        type: "method",
        detail: "() => PIXI.Rectangle | PIXI.Polygon",
        info: "Get the shape of this Token."
      },
      getCenterPoint: {
        type: "method",
        detail: "(position?) => Canvas.Point",
        info: "Get the center point for a given position or the current position."
      },
      getSnappedPosition: {
        type: "method",
        detail: "(position?) => Canvas.Point"
      },
      measureMovementPath: {
        type: "method",
        detail: "(waypoints, options?) => foundry.grid.BaseGrid.MeasurePathResult",
        info: "Measure the movement path for this Token."
      },
      constrainMovementPath: {
        type: "method",
        detail: "(waypoints, { preview, ignoreWalls, ignoreCost, history }?) => Token.ConstrainMovementPathReturn",
        info: "Constrain the given movement path.\n\nThe result of this function must not be affected by the animation of this Token."
      },
      findMovementPath: {
        type: "method",
        detail: "(waypoints, options?) => Token.FindMovementPathJob",
        info: "Find a movement path through the waypoints.\nThe path may not necessarily be one with the least cost.\nThe path returned may be partial, i.e. it doesn't go through all waypoints, but must always start w"
      },
      testInsideRegion: {
        type: "method",
        detail: "(region, position?) => boolean",
        info: "Test whether the Token is inside the Region.\nThis function determines the state of | `TokenDocument#regions` and | `RegionDocument#tokens`.\n\nImplementations of this function are restricted in the foll"
      },
      segmentizeRegionMovement: {
        type: "method",
        detail: "(region, waypoints, options?) => Region.MovementSegment[]",
        info: "Split the Token movement through the waypoints into its segments.\n\nImplementations of this function are restricted in the following ways:\n  - The segments must go through the waypoints.\n  - The *from*"
      },
      setTarget: {
        type: "method",
        detail: "(targeted?, context?) => void",
        info: "Set this Token as an active target for the current game User"
      },
      externalRadius: {
        type: "property",
        detail: "number",
        info: "The external radius of the token in pixels."
      },
      getLightRadius: {
        type: "method",
        detail: "(units) => number",
        info: "A generic transformation to turn a certain number of grid units into a radius in canvas pixels.\nThis function adds additional padding to the light radius equal to the external radius of the token.\nThi"
      },
      updatePosition: {
        type: "method",
        detail: "() => void"
      },
      refreshHUD: {
        type: "method",
        detail: "(options?) => void"
      },
      updateSource: {
        type: "method",
        detail: "(options?) => void",
        info: "Update the light and vision source objects associated with this Token"
      },
      getCenter: {
        type: "method",
        detail: "(x, y) => Canvas.Point",
        info: "Get the center-point coordinate for a given grid position"
      },
      owner: {
        type: "property",
        detail: "boolean",
        info: "A convenient reference for whether the current User has full control over the Token document."
      },
      toggleCombat: {
        type: "method",
        detail: "(combat?) => Promise<Combatant.Stored[]>"
      },
      toggleEffect: {
        type: "method",
        detail: "(effect, options?) => Promise<ActiveEffect.Stored | boolean | undefined>"
      },
      toggleVisibility: {
        type: "method",
        detail: "() => Promise<TokenDocument.Stored[]>"
      }
    }
  },
  Actors: {
    type: "class",
    detail: "Actors",
    staticChildren: {
      documentName: {
        type: "property",
        detail: '"Actor"'
      },
      instance: {
        type: "property",
        detail: "Actors.Implementation"
      }
    },
    instanceChildren: {
      tokens: {
        type: "property",
        detail: "Record<string, Actor.Stored>",
        info: "A mapping of synthetic Token Actors which are currently active within the viewed Scene.\nEach Actor is referenced by the Token.id."
      },
      fromCompendium: {
        type: "method",
        detail: '(document, options?) => WorldCollection.FromCompendiumReturnType<"Actor", Options>'
      }
    }
  },
  ClientSettings: {
    type: "class",
    detail: "ClientSettings",
    constructorDetail: "(worldSettings?) => ClientSettings",
    instanceChildren: {
      settings: {
        type: "property",
        detail: "ClientSettings.SettingsMap",
        info: "A object of registered game settings for this scope"
      },
      menus: {
        type: "property",
        detail: "Map<string, ClientSettings.SettingSubmenuConfig>",
        info: "Registered settings menus which trigger secondary applications"
      },
      storage: {
        type: "property",
        detail: "Map<string, Storage | collections.WorldSettings.Implementation>",
        info: "The storage interfaces used for persisting settings\nEach storage interface shares the same API as window.localStorage"
      },
      sheet: {
        type: "property",
        detail: "foundry.applications.settings.SettingsConfig",
        info: "Return a singleton instance of the Game Settings Configuration app"
      },
      register: {
        type: "method",
        detail: "(namespace, key, data) => void",
        info: "Register a new namespaced game setting. The setting's scope determines where the setting is saved.\nWorld - World settings are applied to everyone in the World. Use this for settings like system rule v"
      },
      registerMenu: {
        type: "method",
        detail: "(namespace, key, data) => void",
        info: "Register a new sub-settings menu"
      },
      get: {
        type: "method",
        detail: "(namespace, key, options?) => ClientSettings.Get<N, K, Doc>",
        info: "Get the value of a game setting for a certain namespace and setting key"
      },
      set: {
        type: "method",
        detail: "(namespace, key, value, options?) => Promise<ClientSettings.Get<N, K, Doc>>",
        info: "Set the value of a game setting for a certain namespace and setting key"
      }
    }
  },
  Localization: {
    type: "class",
    detail: "Localization",
    constructorDetail: "(serverLanguage?) => Localization",
    staticChildren: {
      localizeDataModel: {
        type: "method",
        detail: "(model, options?) => void",
        info: "Perform one-time localization of the fields in a DataModel schema, translating their label and hint properties."
      },
      localizeSchema: {
        type: "method",
        detail: "(schema, prefixes?, options?) => void",
        info: 'Localize the "label" and "hint" properties for all fields in a data schema.'
      }
    },
    instanceChildren: {
      lang: {
        type: "property",
        detail: "string",
        info: "The target language for localization"
      },
      defaultModule: {
        type: "property",
        detail: "string",
        info: "The package authorized to provide default language configurations"
      },
      translations: {
        type: "property",
        detail: "Localization.Translations",
        info: "The translation dictionary for the target language"
      },
      initialize: {
        type: "method",
        detail: "() => Promise<void>",
        info: "Initialize the Localization module\nDiscover available language translations and apply the current language setting"
      },
      setLanguage: {
        type: "method",
        detail: "(lang) => Promise<void>",
        info: "Set a language as the active translation source for the session"
      },
      has: {
        type: "method",
        detail: "(stringId, fallback?) => boolean",
        info: "Return whether a certain string has a known translation defined."
      },
      localize: {
        type: "method",
        detail: "(stringId) => string",
        info: "Localize a string by drawing a translation from the available translations dictionary, if available\nIf a translation is not available, the original string is returned"
      },
      format: {
        type: "method",
        detail: "(stringId, data?) => string",
        info: "Localize a string including variable formatting for input arguments.\nProvide a string ID which defines the localized template.\nVariables can be included in the template enclosed in braces and will be "
      },
      getListFormatter: {
        type: "method",
        detail: "(options?) => Intl.ListFormat",
        info: "Retrieve list formatter configured to the world's language setting."
      },
      sortObjects: {
        type: "method",
        detail: "(objects, key) => T[]",
        info: "Sort an array of objects by a given key in a localization-aware manner."
      }
    }
  },
  Items: {
    type: "class",
    detail: "Items",
    staticChildren: {
      documentName: {
        type: "property",
        detail: '"Item"'
      },
      instance: {
        type: "property",
        detail: "Items.Implementation"
      }
    }
  },
  Users: {
    type: "class",
    detail: "Users",
    constructorDetail: "(data?) => Users",
    staticChildren: {
      documentName: {
        type: "property",
        detail: '"User"'
      },
      instance: {
        type: "property",
        detail: "Users.Implementation"
      }
    },
    instanceChildren: {
      current: {
        type: "property",
        detail: "User.Stored | null",
        info: "The User document of the currently connected user"
      },
      players: {
        type: "property",
        detail: "User.Stored[]",
        info: "Get the users with player roles"
      },
      activeGM: {
        type: "property",
        detail: "User.Stored | null",
        info: "Get one User who is an active Gamemaster (non-assistant if possible), or null if no active GM is available.\nThis can be useful for workflows which occur on all clients, but where only one user should "
      },
      getDesignatedUser: {
        type: "method",
        detail: "(condition) => User.Stored | null",
        info: "Get the designated User among the Users that satisfy the given condition.\nReturns `null` if no Users satisfy the given condition.\nReturns a User with the highest role among the qualifying Users.\nQuali"
      }
    }
  },
  Notifications: {
    type: "class",
    detail: "Notifications",
    constructorDetail: "() => Notifications",
    staticChildren: {
      MAX_ACTIVE: {
        type: "property",
        detail: "number",
        info: "The maximum number of active notifications."
      },
      LIFETIME_MS: {
        type: "property",
        detail: "number",
        info: "The maximum number of active notifications."
      }
    },
    instanceChildren: {
      notify: {
        type: "method",
        detail: '(message, type?, options?) => Notifications.Notification<Coalesce<T, "info">>',
        info: "Push a new notification into the queue"
      },
      info: {
        type: "method",
        detail: '(message, options?) => Notifications.Notification<"info">',
        info: 'Display a notification with the "info" type'
      },
      warn: {
        type: "method",
        detail: '(message, options?) => Notifications.Notification<"warning">',
        info: 'Display a notification with the "warning" type'
      },
      error: {
        type: "method",
        detail: '(message, options?) => Notifications.Notification<"error">',
        info: 'Display a notification with the "error" type'
      },
      success: {
        type: "method",
        detail: '(message, options?) => Notifications.Notification<"success">',
        info: 'Display a notification with the "success" type.'
      },
      update: {
        type: "method",
        detail: "(notification, update) => void",
        info: "Update the progress of the notification."
      },
      remove: {
        type: "method",
        detail: "(id) => void",
        info: "Remove the notification linked to the ID."
      },
      has: {
        type: "method",
        detail: "(id) => boolean",
        info: "Does the notification linked to the ID exist?."
      },
      clear: {
        type: "method",
        detail: "() => void",
        info: "Clear all notifications."
      }
    }
  },
  ActiveEffect: {
    type: "class",
    detail: "ActiveEffect",
    constructorDetail: "(data, context?) => ActiveEffect",
    staticChildren: {
      fromStatusEffect: {
        type: "method",
        detail: "(statusId, options?) => Promise<ActiveEffect.Implementation>",
        info: "Create an ActiveEffect instance from some status effect ID.\nDelegates to  to create the ActiveEffect instance\nafter creating the ActiveEffect data from the status effect data if `CONFIG.statusEffects`"
      },
      applyField: {
        type: "method",
        detail: "(model, change, field?) => ActiveEffect.ApplyFieldReturn<Field>",
        info: "Apply ActiveEffect.EffectChangeData to a field within a DataModel."
      },
      getInitialDuration: {
        type: "method",
        detail: "() => ActiveEffect.GetInitialDurationReturn",
        info: "Retrieve the initial duration configuration."
      },
      defaultName: {
        type: "method",
        detail: "(context) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data, createOptions, options?) => Promise<ActiveEffect.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<ActiveEffect.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<ActiveEffect.Implementation>"
      }
    },
    instanceChildren: {
      isSuppressed: {
        type: "property",
        detail: "boolean",
        info: "Is there some system logic that makes this active effect ineligible for application?"
      },
      target: {
        type: "property",
        detail: "Document.Any | null",
        info: "Retrieve the Document that this ActiveEffect targets for modification."
      },
      active: {
        type: "property",
        detail: "boolean",
        info: "Whether the Active Effect currently applying its changes to the target."
      },
      modifiesActor: {
        type: "property",
        detail: "boolean",
        info: "Does this Active Effect currently modify an Actor?"
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      updateDuration: {
        type: "method",
        detail: "() => ActiveEffect.Duration",
        info: "Update derived Active Effect duration data.\nConfigure the remaining and label properties to be getters which lazily recompute only when necessary."
      },
      isTemporary: {
        type: "property",
        detail: "boolean",
        info: "Describe whether the ActiveEffect has a temporary duration based on combat turns or rounds."
      },
      sourceName: {
        type: "property",
        detail: "string",
        info: 'The source name of the Active Effect. The source is retrieved synchronously.\nTherefore "Unknown" (localized) is returned if the origin points to a document inside a compendium.\nReturns "None" (localiz'
      },
      apply: {
        type: "method",
        detail: "(actor, change) => AnyMutableObject",
        info: "Apply this ActiveEffect to a provided Actor."
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Actor: {
    type: "class",
    detail: "Actor",
    constructorDetail: "(data, context?) => Actor",
    instancePath: "actor",
    staticChildren: {
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<Actor.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Actor.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Actor.Implementation>"
      }
    },
    instanceChildren: {
      overrides: {
        type: "property",
        detail: "Record<string, unknown>",
        info: "An object that tracks which tracks the changes to the data model which were applied by active effects"
      },
      statuses: {
        type: "property",
        detail: "Set<string>",
        info: "The statuses that are applied to this actor by active effects"
      },
      thumbnail: {
        type: "property",
        detail: "string | null",
        info: "Provide a thumbnail image path used to represent this document."
      },
      itemTypes: {
        type: "property",
        detail: "Actor.ItemTypes",
        info: "A convenience getter to an object that organizes all embedded Item instances by subtype. The object is cached and\nlazily re-computed as needed."
      },
      isToken: {
        type: "property",
        detail: "boolean",
        info: "Test whether an Actor document is a synthetic representation of a Token (if true) or a full Document (if false)"
      },
      appliedEffects: {
        type: "property",
        detail: "ActiveEffect.Implementation[]",
        info: "Retrieve the list of ActiveEffects that are currently applied to this Actor."
      },
      temporaryEffects: {
        type: "property",
        detail: "ActiveEffect.Implementation[]",
        info: "An array of ActiveEffect instances which are present on the Actor which have a limited duration."
      },
      token: {
        type: "property",
        detail: "TokenDocument.Implementation | null",
        info: "Return a reference to the TokenDocument which owns this Actor as a synthetic override"
      },
      inCombat: {
        type: "property",
        detail: "boolean",
        info: "Whether the Actor has at least one Combatant in the active Combat that represents it."
      },
      clone: {
        type: "method",
        detail: "(data?, context?) => Document.Clone<this, Save>"
      },
      applyActiveEffects: {
        type: "method",
        detail: "() => void",
        info: "Apply any transformations to the Actor data which are caused by ActiveEffects."
      },
      getActiveTokens: {
        type: "method",
        detail: "(linked?, document?) => Actor.GetActiveTokensReturn<ReturnDocument>",
        info: "Retrieve an Array of active tokens which represent this Actor in the current canvas Scene.\nIf the canvas is not currently active, or there are no linked actors, the returned Array will be empty.\nIf th"
      },
      allApplicableEffects: {
        type: "method",
        detail: "() => Generator<ActiveEffect.Implementation, void, undefined>",
        info: "Get all ActiveEffects that may apply to this Actor.\nIf CONFIG.ActiveEffect.legacyTransferral is true, this is equivalent to actor.effects.contents.\nIf CONFIG.ActiveEffect.legacyTransferral is false, t"
      },
      getRollData: {
        type: "method",
        detail: "() => AnyObject",
        info: "Prepare a data object which defines the data schema used by dice roll commands against this Actor"
      },
      getTokenDocument: {
        type: "method",
        detail: "(data?, options?) => Promise<TokenDocument.Implementation>",
        info: "Create a new TokenData object which can be used to create a Token representation of the Actor."
      },
      getTokenImages: {
        type: "method",
        detail: "() => Promise<string[]>",
        info: "Get an Array of Token images which could represent this Actor"
      },
      modifyTokenAttribute: {
        type: "method",
        detail: "(attribute, value, isDelta?, isBar?) => Promise<this | undefined>",
        info: "Handle how changes to a Token attribute bar are applied to the Actor.\nThis allows for game systems to override this behavior and deploy special logic."
      },
      prepareData: {
        type: "method",
        detail: "() => void"
      },
      prepareEmbeddedDocuments: {
        type: "method",
        detail: "() => void"
      },
      rollInitiative: {
        type: "method",
        detail: "(options?) => Promise<Combat.Implementation | null>",
        info: "Roll initiative for all Combatants in the currently active Combat encounter which are associated with this Actor.\nIf viewing a full Actor document, all Tokens which map to that actor will be targeted "
      },
      toggleStatusEffect: {
        type: "method",
        detail: "(statusId, options?) => Promise<ActiveEffect.Implementation | boolean | undefined>",
        info: "Toggle a configured status effect for the Actor."
      },
      getDependentTokens: {
        type: "method",
        detail: "(options?) => TokenDocument.Implementation[]",
        info: "Get this actor's dependent tokens.\nIf the actor is a synthetic token actor, only the exact Token which it represents will be returned."
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Folder: {
    type: "class",
    detail: "Folder",
    constructorDetail: "(data, context?) => Folder",
    staticChildren: {
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<Folder.Stored | null | undefined>"
      },
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Folder.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Folder.Implementation>"
      }
    },
    instanceChildren: {
      depth: {
        type: "property",
        detail: "number | undefined",
        info: "The depth of this folder in its sidebar tree"
      },
      children: {
        type: "property",
        detail: "Folder.ChildNode | undefined",
        info: "An array of nodes representing the children of this one. This differs from the results of\n| `Folder#getSubfolders`, which reports the subset of child Folders\ndisplayed to the current User in the UI.\n\n"
      },
      displayed: {
        type: "property",
        detail: "boolean",
        info: "Return whether the folder is displayed in the sidebar to the current User."
      },
      contents: {
        type: "property",
        detail: "Folder.Contents<SubType>",
        info: "The array of the Document instances which are contained within this Folder,\nunless it's a Folder inside a Compendium pack, in which case it's the array\nof objects inside the index of the pack that are"
      },
      documentClass: {
        type: "property",
        detail: "Folder.DocumentClass<SubType>",
        info: "The reference to the Document type which is contained within this Folder."
      },
      documentCollection: {
        type: "property",
        detail: "Folder.DocumentCollection<SubType>",
        info: "The reference to the WorldCollection instance which provides Documents to this Folder,\nunless it's a Folder inside a Compendium pack, in which case it's the index of the pack.\nA world Folder containin"
      },
      expanded: {
        type: "property",
        detail: "boolean",
        info: "Return whether the folder is currently expanded within the sidebar interface."
      },
      ancestors: {
        type: "property",
        detail: "Folder.Stored[]",
        info: "Return the list of ancestors of this folder, starting with the parent."
      },
      inCompendium: {
        type: "property",
        detail: "boolean"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      },
      exportToCompendium: {
        type: "method",
        detail: "(pack, options?) => Promise<Pack>",
        info: "Export all Documents contained in this Folder to a given Compendium pack.\nOptionally update existing Documents within the Pack by name, otherwise append all new entries."
      },
      exportDialog: {
        type: "method",
        detail: "(pack, options?) => Promise<void>",
        info: "Provide a dialog form that allows for exporting the contents of a Folder into an eligible Compendium pack."
      },
      getSubfolders: {
        type: "method",
        detail: "(recursive?) => Folder.Stored<SubType>[]",
        info: "Get the Folder documents which are sub-folders of the current folder, either direct children or recursively."
      },
      getParentFolders: {
        type: "method",
        detail: "() => Folder.Stored<SubType>[]",
        info: "Get the Folder documents which are parent folders of the current folder or any if its parents."
      }
    }
  },
  Roll: {
    type: "class",
    detail: "Roll",
    constructorDetail: "(formula, data?, options?) => Roll",
    staticChildren: {
      MATH_PROXY: {
        type: "property",
        detail: "Math",
        info: "A Proxy environment for safely evaluating a string using only available Math functions"
      },
      CHAT_TEMPLATE: {
        type: "property",
        detail: "string",
        info: "The HTML template path used to render a complete Roll object to the chat log"
      },
      TOOLTIP_TEMPLATE: {
        type: "property",
        detail: "string",
        info: "The HTML template used to render an expanded Roll tooltip to the chat log"
      },
      RESOLVERS: {
        type: "property",
        detail: "Map<Roll, RollResolver>",
        info: "A mapping of Roll instances to currently-active resolvers."
      },
      create: {
        type: "method",
        detail: "(formula, data?, options?) => typeof CONFIG.Dice.rolls extends [infer T] ? T : Roll<D>",
        info: "A factory method which constructs a Roll instance using the default configured Roll class."
      },
      defaultImplementation: {
        type: "property",
        detail: "typeof Roll",
        info: "Get the default configured Roll class."
      },
      resolverImplementation: {
        type: "property",
        detail: "typeof RollResolver",
        info: "Retrieve the appropriate resolver implementation based on the user's configuration."
      },
      getFormula: {
        type: "method",
        detail: "(terms) => string",
        info: "Transform an array of RollTerm objects into a cleaned string formula representation."
      },
      safeEval: {
        type: "method",
        detail: "(expression) => number",
        info: "A sandbox-safe evaluation function to execute user-input code with access to scoped Math methods."
      },
      simplifyTerms: {
        type: "method",
        detail: "(terms) => RollTerm[]",
        info: "After parenthetical and arithmetic terms have been resolved, we need to simplify the remaining expression.\nAny remaining string terms need to be combined with adjacent non-operators in order to constr"
      },
      simulate: {
        type: "method",
        detail: "(formula, n?) => Promise<number[]>",
        info: "Simulate a roll and evaluate the distribution of returned results"
      },
      registerResult: {
        type: "method",
        detail: "(method, denomination, result) => boolean | void",
        info: "Register an externally-fulfilled result with an active RollResolver."
      },
      parse: {
        type: "method",
        detail: "(formula, data) => RollTerm[]",
        info: "Parse a formula expression using the compiled peggy grammar."
      },
      instantiateAST: {
        type: "method",
        detail: "(ast) => RollTerm[]",
        info: "Instantiate the nodes in an AST sub-tree into RollTerm instances."
      },
      replaceFormulaData: {
        type: "method",
        detail: "(formula, data, options?) => string",
        info: "Replace referenced data attributes in the roll formula with values from the provided data.\nData references in the formula use the \\@attr syntax and would reference the corresponding attr key."
      },
      validate: {
        type: "method",
        detail: "(formula) => boolean",
        info: "Validate that a provided roll formula can represent a valid"
      },
      identifyFulfillableTerms: {
        type: "method",
        detail: "(terms) => DiceTerm[]",
        info: "Determine which of the given terms require external fulfillment."
      },
      expandInlineResult: {
        type: "method",
        detail: "(a) => Promise<void>",
        info: "Expand an inline roll element to display its contained dice result as a tooltip."
      },
      collapseInlineResult: {
        type: "method",
        detail: "(a) => void",
        info: "Collapse an expanded inline roll to conceal its tooltip."
      },
      fromData: {
        type: "method",
        detail: "(this, data) => FixedInstanceType<T>",
        info: "Recreate a Roll instance using a provided data object"
      },
      fromJSON: {
        type: "method",
        detail: "(this, json) => FixedInstanceType<T>",
        info: "Recreate a Roll instance using a provided JSON string"
      },
      fromTerms: {
        type: "method",
        detail: "(this, terms, options?) => FixedInstanceType<T>",
        info: "Manually construct a Roll object by providing an explicit set of input terms"
      }
    },
    instanceChildren: {
      data: {
        type: "property",
        detail: "D",
        info: "The original provided data object which substitutes into attributes of the roll formula"
      },
      options: {
        type: "property",
        detail: "Roll.Options",
        info: "Options which modify or describe the Roll"
      },
      terms: {
        type: "property",
        detail: "RollTerm[]",
        info: "The identified terms of the Roll"
      },
      dice: {
        type: "property",
        detail: "DiceTerm[]",
        info: "Return an Array of the individual DiceTerm instances contained within this Roll."
      },
      formula: {
        type: "property",
        detail: "string",
        info: "Return a standardized representation for the displayed formula associated with this Roll."
      },
      result: {
        type: "property",
        detail: "string",
        info: "The resulting arithmetic expression after rolls have been evaluated"
      },
      total: {
        type: "property",
        detail: "number | undefined",
        info: "Return the total result of the Roll expression if it has been evaluated."
      },
      product: {
        type: "property",
        detail: "number | undefined",
        info: "Return the arbitrary product of evaluating this Roll."
      },
      isDeterministic: {
        type: "property",
        detail: "boolean",
        info: "Whether this Roll contains entirely deterministic terms or whether there is some randomness."
      },
      alter: {
        type: "method",
        detail: "(multiply, add, { multiplyNumeric }?) => this",
        info: "Alter the Roll expression by adding or multiplying the number of dice which are rolled"
      },
      clone: {
        type: "method",
        detail: "() => this",
        info: "Clone the Roll instance, returning a new Roll instance that has not yet been evaluated."
      },
      evaluate: {
        type: "method",
        detail: "({\n    minimize,\n    maximize,\n    allowStrings,\n    allowInteractive,\n    ...options\n  }?) => Promise<Roll.Evaluated<this>>",
        info: "Execute the Roll, replacing dice and evaluating the total result"
      },
      evaluateSync: {
        type: "method",
        detail: "({ minimize, maximize, allowStrings, strict }?) => Roll.Evaluated<this>",
        info: "Execute the Roll synchronously, replacing dice and evaluating the total result."
      },
      roll: {
        type: "method",
        detail: "(options?) => Promise<Roll.Evaluated<this>>",
        info: "Alias for evaluate."
      },
      reroll: {
        type: "method",
        detail: "(options?) => Promise<Roll.Evaluated<this>>",
        info: "Create a new Roll object using the original provided formula and data.\nEach roll is immutable, so this method returns a new Roll instance using the same data."
      },
      resetFormula: {
        type: "method",
        detail: "() => string",
        info: "Recompile the formula string that represents this Roll instance from its component terms."
      },
      propagateFlavor: {
        type: "method",
        detail: "(flavor) => void",
        info: "Propagate flavor text across all terms that do not have any."
      },
      getTooltip: {
        type: "method",
        detail: "() => Promise<string>",
        info: "Render the tooltip HTML for a Roll instance"
      },
      render: {
        type: "method",
        detail: "(options?) => Promise<string>",
        info: "Render a Roll instance to HTML"
      },
      toMessage: {
        type: "method",
        detail: "(messageData?, options?) => Promise<Roll.ToMessageReturn<Create>>",
        info: "Transform a Roll instance into a ChatMessage, displaying the roll result.\nThis function can either create the ChatMessage directly, or return the data object that will be used to create."
      },
      toAnchor: {
        type: "method",
        detail: "(options?) => HTMLAnchorElement",
        info: "Construct an inline roll link for this Roll."
      }
    }
  },
  Game: {
    type: "class",
    detail: "Game"
  },
  ChatMessage: {
    type: "class",
    detail: "ChatMessage",
    constructorDetail: "(data?, context?) => ChatMessage",
    staticChildren: {
      applyRollMode: {
        type: "method",
        detail: "(chatData, rollMode) => ChatMessage.CreateData",
        info: "Transform a provided object of ChatMessage data by applying a certain roll mode to the data object.\n - Public: `whisper` is set to `[]` and `blind` is set to `false`.\n - Self: `whisper` is set to `[ga"
      },
      getSpeaker: {
        type: "method",
        detail: "(options?) => ChatMessage.SpeakerData",
        info: "Attempt to determine who is the speaking character (and token) for a certain Chat Message\nFirst assume that the currently controlled Token is the speaker"
      },
      getSpeakerActor: {
        type: "method",
        detail: "(speaker?) => Actor.Implementation | null",
        info: "Obtain an Actor instance which represents the speaker of this message (if any)"
      },
      getWhisperRecipients: {
        type: "method",
        detail: "(name) => User.Stored[]",
        info: "Given a string whisper target, return an Array of the user IDs which should be targeted for the whisper"
      },
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<ChatMessage.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<ChatMessage.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<ChatMessage.Implementation>"
      }
    },
    instanceChildren: {
      logged: {
        type: "property",
        detail: "boolean",
        info: "Is this ChatMessage currently displayed in the sidebar ChatLog?"
      },
      alias: {
        type: "property",
        detail: "string",
        info: "Return the recommended String alias for this message.\nThe alias could be a Token name in the case of in-character messages or dice rolls.\nAlternatively it could be a User name in the case of OOC chat "
      },
      isAuthor: {
        type: "property",
        detail: "boolean",
        info: "Is the current User the author of this message?"
      },
      isContentVisible: {
        type: "property",
        detail: "boolean",
        info: "Return whether the content of the message is visible to the current user.\nFor certain dice rolls, for example, the message itself may be visible while the content of that message is not."
      },
      isRoll: {
        type: "property",
        detail: "boolean",
        info: "Test whether the chat message contains a dice roll"
      },
      visible: {
        type: "property",
        detail: "boolean",
        info: "Return whether the ChatMessage is visible to the current User.\nMessages may not be visible if they are private whispers."
      },
      speakerActor: {
        type: "property",
        detail: "Actor.Implementation | null",
        info: "The Actor which represents the speaker of this message (if any)."
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      applyRollMode: {
        type: "method",
        detail: "(rollMode) => void",
        info: "Update the data of a ChatMessage instance to apply a requested roll mode.\nThis function calls  and updates the source of the ChatMessage."
      },
      getRollData: {
        type: "method",
        detail: "() => AnyObject",
        info: "Obtain a data object used to evaluate any dice rolls associated with this particular chat message"
      },
      renderHTML: {
        type: "method",
        detail: "(options?) => Promise<HTMLElement>",
        info: "Render the HTML for the ChatMessage which should be added to the log"
      },
      export: {
        type: "method",
        detail: "() => string",
        info: "Export the content of the chat message into a standardized log format"
      },
      getHTML: {
        type: "method",
        detail: "() => Promise<JQuery>"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Combat: {
    type: "class",
    detail: "Combat",
    constructorDetail: "(data?, context?) => Combat",
    staticChildren: {
      CONFIG_SETTING: {
        type: "property",
        detail: '"combatTrackerConfig"',
        info: "The configuration setting used to record Combat preferences"
      },
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<Combat.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Combat.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Combat.Implementation>"
      }
    },
    instanceChildren: {
      turns: {
        type: "property",
        detail: "Combatant.Implementation[]",
        info: "Track the sorted turn order of this combat encounter"
      },
      current: {
        type: "property",
        detail: "Combat.HistoryData",
        info: "Record the current round, turn, and tokenId to understand changes in the encounter state"
      },
      previous: {
        type: "property",
        detail: "Combat.HistoryData | undefined",
        info: "Track the previous round, turn, and tokenId to understand changes in the encounter state"
      },
      combatant: {
        type: "property",
        detail: "Combatant.Implementation | undefined | null",
        info: "Get the Combatant who has the current turn."
      },
      nextCombatant: {
        type: "property",
        detail: "Combatant.Implementation | undefined",
        info: "Get the Combatant who has the next turn."
      },
      settings: {
        type: "property",
        detail: 'foundry.helpers.ClientSettings.SettingInitializedType<"core", Combat.CONFIG_SETTING>',
        info: "Return the object of settings which modify the Combat Tracker behavior"
      },
      started: {
        type: "property",
        detail: "boolean",
        info: "Has this combat encounter been started?"
      },
      visible: {
        type: "property",
        detail: "boolean"
      },
      isActive: {
        type: "property",
        detail: "boolean",
        info: "Is this combat active in the current scene?"
      },
      isView: {
        type: "property",
        detail: "boolean",
        info: "Is this Combat currently being viewed?"
      },
      activate: {
        type: "method",
        detail: "(options?) => Promise<Combat.Implementation[]>",
        info: "Set the current Combat encounter as active within the Scene.\nDeactivate all other Combat encounters within the viewed Scene and set this one as active"
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      getCombatantsByToken: {
        type: "method",
        detail: "(token) => Combatant.Implementation[]",
        info: "Get a Combatant using its Token id"
      },
      getCombatantsByActor: {
        type: "method",
        detail: "(actorOrId) => Combatant.Implementation[]",
        info: "Get a Combatant that represents the given Actor or Actor ID."
      },
      getTimeDelta: {
        type: "method",
        detail: "(fromRound, fromTurn, toRound, toTurn) => number",
        info: "Calculate the time delta between two turns."
      },
      startCombat: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Begin the combat encounter, advancing to round 1 and turn 1"
      },
      nextRound: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Advance the combat to the next round"
      },
      previousRound: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Rewind the combat to the previous round"
      },
      nextTurn: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Advance the combat to the next turn"
      },
      previousTurn: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Rewind the combat to the previous turn"
      },
      endCombat: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Display a dialog querying the GM whether they wish to end the combat encounter and empty the tracker"
      },
      toggleSceneLink: {
        type: "method",
        detail: "() => Promise<this>",
        info: "Toggle whether this combat is linked to the scene or globally available."
      },
      resetAll: {
        type: "method",
        detail: "() => Promise<this | undefined>",
        info: "Reset all combatant initiative scores, setting the turn back to zero"
      },
      rollInitiative: {
        type: "method",
        detail: "(ids, options?) => Promise<this>",
        info: "Roll initiative for one or multiple Combatants within the Combat document"
      },
      rollAll: {
        type: "method",
        detail: "(options?) => Promise<this>",
        info: "Roll initiative for all combatants which have not already rolled"
      },
      rollNPC: {
        type: "method",
        detail: "(options?) => Promise<this>",
        info: "Roll initiative for all non-player actors who have not already rolled"
      },
      setInitiative: {
        type: "method",
        detail: "(id, value) => Promise<void>",
        info: "Assign initiative for a single Combatant within the Combat encounter.\nUpdate the Combat turn order to maintain the same combatant as the current turn."
      },
      setupTurns: {
        type: "method",
        detail: "() => Combatant.Implementation[]",
        info: "Return the Array of combatants sorted into initiative order, breaking ties alphabetically by name."
      },
      debounceSetup: {
        type: "property",
        detail: "() => void",
        info: "Debounce changes to the composition of the Combat encounter to de-duplicate multiple concurrent Combatant changes.\nIf this is the currently viewed encounter, re-render the CombatTracker application."
      },
      updateCombatantActors: {
        type: "method",
        detail: "() => void",
        info: "Update active effect durations for all actors present in this Combat encounter."
      },
      clearMovementHistories: {
        type: "method",
        detail: "(combatants?) => Promise<void>",
        info: "Clear the movement history of all Tokens within this Combat.\nor\nClear the movement history of the Combatants' Tokens."
      },
      getCombatantByActor: {
        type: "method",
        detail: "(actor) => Combatant.Implementation | null"
      },
      getCombatantByToken: {
        type: "method",
        detail: "(token) => Combatant.Implementation | null"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Scene: {
    type: "class",
    detail: "Scene",
    constructorDetail: "(data, context?) => Scene",
    staticChildren: {
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<Scene.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Scene.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Scene.Implementation>"
      }
    },
    instanceChildren: {
      grid: {
        type: "property",
        detail: "foundry.grid.BaseGrid",
        info: "The grid instance."
      },
      dimensions: {
        type: "property",
        detail: "Scene.Dimensions",
        info: "Determine the canvas dimensions this Scene would occupy, if rendered"
      },
      thumbnail: {
        type: "property",
        detail: "string | null",
        info: "Provide a thumbnail image path used to represent this document."
      },
      isView: {
        type: "property",
        detail: "boolean",
        info: "A convenience accessor for whether the Scene is currently viewed"
      },
      pullUsers: {
        type: "method",
        detail: "(users?) => void",
        info: "Pull the specified users to this Scene."
      },
      activate: {
        type: "method",
        detail: "() => Promise<this | undefined>",
        info: "Set this scene as currently active"
      },
      view: {
        type: "method",
        detail: "() => Promise<this | number>",
        info: "Set this scene as the current view"
      },
      unview: {
        type: "method",
        detail: "() => Promise<this | undefined>",
        info: "Unview the current Scene, clearing the game canvas."
      },
      clone: {
        type: "method",
        detail: "(data?, context?) => Document.Clone<this, Save>"
      },
      reset: {
        type: "method",
        detail: "() => void"
      },
      toObject: {
        type: "method",
        detail: "(source?) => fields.SchemaField.SourceData<Scene.Schema>"
      },
      prepareBaseData: {
        type: "method",
        detail: "() => void"
      },
      getDimensions: {
        type: "method",
        detail: "() => Scene.Dimensions",
        info: "Get the Canvas dimensions which would be used to display this Scene.\nApply padding to enlarge the playable space and round to the nearest 2x grid size to ensure symmetry.\nThe rounding accomplishes tha"
      },
      clearMovementHistories: {
        type: "method",
        detail: "() => Promise<void>",
        info: "Clear the movement history of all Tokens within this Scene."
      },
      updateTokenRegions: {
        type: "method",
        detail: "(tokens?) => Promise<TokenDocument.Implementation[]>",
        info: "For all Tokens in this Scene identify the Regions that each Token is contained in and update the regions of each\nToken accordingly.\nor\nFor the given Tokens in this Scene identify the Regions that each"
      },
      toCompendium: {
        type: "method",
        detail: '(pack?, options?) => ClientDocument.ToCompendiumReturnType<"Scene", Options>'
      },
      createThumbnail: {
        type: "method",
        detail: "(data?) => Promise<ImageHelper.ThumbnailReturn>",
        info: "Create a 300px by 100px thumbnail image for this scene background"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  User: {
    type: "class",
    detail: "User",
    constructorDetail: "(data, context?) => User",
    staticChildren: {
      defaultName: {
        type: "method",
        detail: "(context?) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data?, createOptions?, options?) => Promise<User.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<User.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<User.Implementation>"
      }
    },
    instanceChildren: {
      active: {
        type: "property",
        detail: "boolean",
        info: "Track whether the user is currently active in the game"
      },
      targets: {
        type: "property",
        detail: "UserTargets",
        info: "Track references to the current set of Tokens which are targeted by the User"
      },
      viewedScene: {
        type: "property",
        detail: "string | null",
        info: "Track the ID of the Scene that is currently being viewed by the User"
      },
      movingTokens: {
        type: "property",
        detail: "Set<TokenDocument.Implementation>",
        info: "Track the Token documents that this User is currently moving."
      },
      isTrusted: {
        type: "property",
        detail: "boolean",
        info: "A flag for whether the current User is a Trusted Player"
      },
      isSelf: {
        type: "property",
        detail: "boolean",
        info: "A flag for whether this User is the connected client"
      },
      isActiveGM: {
        type: "property",
        detail: "boolean",
        info: "Is this User the active GM?"
      },
      roleLabel: {
        type: "property",
        detail: "string",
        info: "A localized label for this User's role."
      },
      lastActivityTime: {
        type: "property",
        detail: "number",
        info: "The timestamp of the lats observed activity for the user."
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      isDesignated: {
        type: "method",
        detail: "(condition) => boolean",
        info: "Is this User the designated User among the Users that satisfy the given condition?\nThis function calls | `foundry.documents.collections.Users#getDesignatedUser` and compares the designated User\nto thi"
      },
      border: {
        type: "property",
        detail: "Color"
      },
      assignHotbarMacro: {
        type: "method",
        detail: "(macro, slot?, options?) => Promise<this | undefined>",
        info: "Assign a Macro to a numbered hotbar slot between 1 and 50"
      },
      assignPermission: {
        type: "method",
        detail: "(permission, allowed) => Promise<this | undefined>",
        info: "Assign a specific boolean permission to this user.\nModifies the user permissions to grant or restrict access to a feature."
      },
      broadcastActivity: {
        type: "method",
        detail: "(activityData?, options?) => void",
        info: "Submit User activity data to the server for broadcast to other players.\nThis type of data is transient, persisting only for the duration of the session and not saved to any database.\nActivity data use"
      },
      getHotbarMacros: {
        type: "method",
        detail: "(page?) => User.GetHotbarMacrosData[]",
        info: "Get an Array of Macro Documents on this User's Hotbar by page"
      },
      query: {
        type: "method",
        detail: "(queryName, queryData, { timeout }?) => Promise<User.QueryReturn<QueryName>>",
        info: "Query this user"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  Combatant: {
    type: "class",
    detail: "Combatant",
    constructorDetail: "(data, context) => Combatant",
    staticChildren: {
      defaultName: {
        type: "method",
        detail: "(context) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data, createOptions, options?) => Promise<Combatant.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<Combatant.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<Combatant.Implementation>"
      }
    },
    instanceChildren: {
      resource: {
        type: "property",
        detail: "Combatant.Resource | null",
        info: "The current value of the special tracked resource which pertains to this Combatant"
      },
      combat: {
        type: "property",
        detail: "Combat.Implementation | null",
        info: "A convenience alias of Combatant#parent which is more semantically intuitive"
      },
      isNPC: {
        type: "property",
        detail: "boolean",
        info: "This is treated as a non-player combatant if it has no associated actor and no player users who can control it"
      },
      permission: {
        type: "property",
        detail: "CONST.DOCUMENT_OWNERSHIP_LEVELS",
        info: "Eschew `ClientDocument`'s redirection to `Combat#permission` in favor of special ownership determination."
      },
      visible: {
        type: "property",
        detail: "boolean"
      },
      actor: {
        type: "property",
        detail: "Actor.Implementation | null",
        info: "A reference to the Actor document which this Combatant represents, if any"
      },
      token: {
        type: "property",
        detail: "TokenDocument.Implementation | null",
        info: "A reference to the Token document which this Combatant represents, if any"
      },
      players: {
        type: "property",
        detail: "User.Implementation[]",
        info: "An array of non-Gamemaster Users who have ownership of this Combatant."
      },
      isDefeated: {
        type: "property",
        detail: "boolean",
        info: "Has this combatant been marked as defeated?"
      },
      getInitiativeRoll: {
        type: "method",
        detail: "(formula?) => Roll.Implementation",
        info: "Get a Roll object which represents the initiative roll for this Combatant."
      },
      rollInitiative: {
        type: "method",
        detail: "(formula?) => Promise<this | undefined>",
        info: "Roll initiative for this particular combatant."
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      updateResource: {
        type: "method",
        detail: "() => Combatant.Resource",
        info: "Update the value of the tracked resource for this Combatant."
      },
      clearMovementHistory: {
        type: "method",
        detail: "() => Promise<void>",
        info: "Clear the movement history of the Combatant's Token."
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  },
  TokenDocument: {
    type: "class",
    detail: "TokenDocument",
    constructorDetail: "(data?, context?) => TokenDocument",
    staticChildren: {
      createCombatants: {
        type: "method",
        detail: "(tokens, options?) => Promise<Combatant.Implementation[]>",
        info: "Create or remove Combatants for an array of provided Token objects."
      },
      deleteCombatants: {
        type: "method",
        detail: "(tokens, options?) => Promise<Combatant.Implementation[]>",
        info: "Remove Combatants for the array of provided Tokens."
      },
      getTrackedAttributes: {
        type: "method",
        detail: "(data?, _path?) => TokenDocument.TrackedAttributesDescription",
        info: "Get an Array of attribute choices which could be tracked for Actors in the Combat Tracker"
      },
      getTrackedAttributeChoices: {
        type: "method",
        detail: "(attributes?) => TokenDocument.TrackedAttributesChoice[]",
        info: "Inspect the Actor data model and identify the set of attributes which could be used for a Token Bar"
      },
      defaultName: {
        type: "method",
        detail: "(context) => string"
      },
      createDialog: {
        type: "method",
        detail: "(data, createOptions, options?) => Promise<TokenDocument.Stored | null | undefined>"
      },
      fromDropData: {
        type: "method",
        detail: "(data, options?) => Promise<TokenDocument.Implementation | undefined>"
      },
      fromImport: {
        type: "method",
        detail: "(source, context?) => Promise<TokenDocument.Implementation>"
      }
    },
    instanceChildren: {
      movement: {
        type: "property",
        detail: "DeepReadonly<TokenDocument.MovementData>",
        info: "The current movement data of this Token document."
      },
      actors: {
        type: "property",
        detail: "TokenDocument.PseudoActorCollection",
        info: "A singleton collection which holds a reference to the synthetic token actor by its base actor's ID."
      },
      actor: {
        type: "property",
        detail: "Actor.Implementation | null",
        info: "A lazily evaluated reference to the Actor this Token modifies.\nIf actorLink is true, then the document is the primary Actor document.\nOtherwise the Actor document is a synthetic (ephemeral) document c"
      },
      baseActor: {
        type: "property",
        detail: "Actor.Implementation | null",
        info: "A reference to the base, World-level Actor this token represents."
      },
      isOwner: {
        type: "property",
        detail: "boolean",
        info: "An indicator for whether or not the current User has full control over this Token document."
      },
      isLinked: {
        type: "property",
        detail: "boolean",
        info: "A convenient reference for whether this TokenDocument is linked to the Actor it represents, or is a synthetic copy"
      },
      isSecret: {
        type: "property",
        detail: "boolean",
        info: "Does this TokenDocument have the SECRET disposition and is the current user lacking the necessary permissions\nthat would reveal this secret?"
      },
      combatant: {
        type: "property",
        detail: "Combatant.Implementation | null",
        info: "Return a reference to a Combatant that represents this Token, if one is present in the current encounter."
      },
      inCombat: {
        type: "property",
        detail: "boolean",
        info: "An indicator for whether or not this Token is currently involved in the active combat encounter."
      },
      movementHistory: {
        type: "property",
        detail: "TokenDocument.MeasuredMovementWaypoint[]",
        info: "The movement history"
      },
      hasDistinctSubjectTexture: {
        type: "property",
        detail: "boolean",
        info: "Check if the document has a distinct subject texture (inferred or explicit)."
      },
      regions: {
        type: "property",
        detail: "Set<RegionDocument.Implementation> | null",
        info: "The Regions this Token is currently in."
      },
      prepareBaseData: {
        type: "method",
        detail: "() => void"
      },
      prepareEmbeddedDocuments: {
        type: "method",
        detail: "() => void"
      },
      prepareDerivedData: {
        type: "method",
        detail: "() => void"
      },
      getBarAttribute: {
        type: "method",
        detail: "(barName, options?) => TokenDocument.GetBarAttributeReturn",
        info: "A helper method to retrieve the underlying data behind one of the Token's attribute bars"
      },
      hasStatusEffect: {
        type: "method",
        detail: "(statusId) => boolean",
        info: "Test whether a Token has a specific status effect."
      },
      move: {
        type: "method",
        detail: "(waypoints, options?) => Promise<boolean>",
        info: "Move the Token through the given waypoint(s)."
      },
      revertRecordedMovement: {
        type: "method",
        detail: "(movementId?) => Promise<boolean>",
        info: "Undo all recorded movement or the recorded movement corresponding to given movement ID up to the last movement.\nThe token is displaced to the prior recorded position and the movement history it rolled"
      },
      resize: {
        type: "method",
        detail: "(dimensions, options?) => Promise<boolean>",
        info: "Resize the token Token such that its center point remains (almost) unchanged. The center point might change\nslightly because the new (x, y) position is rounded."
      },
      stopMovement: {
        type: "method",
        detail: "() => boolean",
        info: "Stop the movement of this Token document. The movement cannot be continued after being stopped.\nOnly the User that initiated the movement can stop it."
      },
      pauseMovement: {
        type: "method",
        detail: "(key?) => (() => Promise<boolean>) | Promise<boolean> | null",
        info: "Pause the movement of this Token document. The movement can be resumed after being paused.\n\nOnly the User that initiated the movement can pause it.\n\nReturns a promise that resolves to true if the move"
      },
      resumeMovement: {
        type: "method",
        detail: "(movementId, key) => void",
        info: "Resume the movement given its ID and the key that was passed to | `TokenDocument#pauseMovement`."
      },
      measureMovementPath: {
        type: "method",
        detail: "(waypoints, options?) => foundry.grid.BaseGrid.MeasurePathResult",
        info: "Measure the movement path for this Token."
      },
      getCompleteMovementPath: {
        type: "method",
        detail: "(waypoints) => TokenDocument.CompleteMovementWaypoint[]",
        info: "Get the path of movement with the intermediate steps of the direct path between waypoints."
      },
      toggleCombatant: {
        type: "method",
        detail: "(options?) => Promise<boolean>",
        info: "Add or remove this Token from a Combat encounter."
      },
      updateVisionMode: {
        type: "method",
        detail: "(visionMode, defaults?) => Promise<TokenDocument.Implementation | undefined>",
        info: "Convenience method to change a token vision mode."
      },
      getEmbeddedCollection: {
        type: "method",
        detail: "(embeddedName) => TokenDocument.GetEmbeddedCollectionResult<EmbeddedName>"
      },
      clearMovementHistory: {
        type: "method",
        detail: "() => Promise<void>",
        info: "Clear the movement history of this Token."
      },
      testInsideRegion: {
        type: "method",
        detail: "(region, data?) => boolean",
        info: "Test whether the Token is inside the Region.\nThis function determines the state of | TokenDocument#regions and\n| foundry.documents.RegionDocument#tokens.\nThe Token and the Region must be in the same S"
      },
      segmentizeRegionMovementPath: {
        type: "method",
        detail: "(region, waypoints) => RegionDocument.MovementSegment[]",
        info: "Split the Token movement path through the Region into its segments.\nThe Token and the Region must be in the same Scene.\n\nImplementations of this function are restricted in the following ways:\n  - The "
      },
      toggleActiveEffect: {
        type: "method",
        detail: "(effectData, options?) => Promise<boolean>",
        info: "A helper function to toggle a status effect which includes an Active Effect template"
      },
      deleteDialog: {
        type: "method",
        detail: "(options?, operation?) => Promise<this | false | null | undefined>"
      }
    }
  }
};

// src/macro-autocomplete.ts
var COMPLETION_TREE = {
  foundry: {
    type: "object",
    detail: "object",
    info: "Foundry VTT core namespace",
    children: {
      utils: {
        type: "object",
        detail: "object",
        info: "Foundry utility functions (populated at runtime)",
        children: {}
      }
    }
  },
  // ── Core macro variables from Foundry's Macro#executeScript ──
  // These are always available in script macros
  // Instance methods populated at runtime by injectPrototypeCompletions()
  speaker: {
    type: "variable",
    detail: "SpeakerData",
    info: "Chat speaker data (always available in macros via Macro#executeScript)",
    children: {}
  },
  character: {
    type: "variable",
    detail: "Actor | null",
    info: "The current user's assigned character (game.user.character)",
    children: {}
  },
  token: {
    type: "variable",
    detail: "Token",
    info: "Token instance (always available in macros via Macro#executeScript)",
    children: {}
  },
  actor: {
    type: "variable",
    detail: "Actor",
    info: "Actor instance (always available in macros via Macro#executeScript)",
    children: {
      // Root document properties populated at runtime from document schema
      // system children populated at runtime by injectSchemaCompletions()
      system: {
        type: "property",
        detail: "object",
        info: "Actor system data (populated from system schema)",
        children: {}
      }
    }
  },
  item: {
    type: "variable",
    detail: "Item",
    info: "Item instance (available in macros via scope)",
    children: {
      system: {
        type: "property",
        detail: "object",
        info: "Item system data (populated from system schema)",
        children: {}
      }
    }
  },
  // Common macro variables
  args: {
    type: "variable",
    detail: "any[]",
    info: "Macro arguments array",
    children: {
      "0": { type: "property", detail: "any", info: "First argument" }
    }
  },
  scope: {
    type: "variable",
    detail: "object",
    info: "Macro scope object (additional named params spread from scope are also available as top-level variables)",
    children: {}
  },
  // CONFIG children populated at runtime by injectConfigCompletions()
  CONFIG: {
    type: "object",
    detail: "object",
    info: "Global Foundry configuration object (populated at runtime)",
    children: {}
  }
};
function fieldToCompletionNode(field, fieldName) {
  const fieldType = field.constructor?.name ?? "unknown";
  const label = field.label ?? fieldName;
  const hint = field.hint ?? "";
  let detail = "any";
  let nodeType = "property";
  if (fieldType === "StringField") {
    detail = "string";
  } else if (fieldType === "NumberField") {
    detail = "number";
  } else if (fieldType === "BooleanField") {
    detail = "boolean";
  } else if (fieldType === "ArrayField") {
    const elementType = field.element?.constructor?.name ?? "any";
    detail = `${elementType}[]`;
  } else if (fieldType === "SetField") {
    const elementType = field.element?.constructor?.name ?? "string";
    detail = `Set<${elementType === "StringField" ? "string" : elementType}>`;
  } else if (fieldType === "SchemaField" || fieldType === "EmbeddedDataField") {
    detail = "object";
  } else if (fieldType === "ObjectField") {
    detail = "object";
  } else if (fieldType === "HTMLField") {
    detail = "string (HTML)";
  } else if (fieldType === "IntegerSortField") {
    detail = "number";
  } else if (fieldType === "DocumentIdField" || fieldType === "ForeignDocumentField") {
    detail = "string (ID)";
  } else if (fieldType === "FilePathField") {
    detail = "string (path)";
  } else if (fieldType === "ColorField") {
    detail = "string (color)";
  } else if (fieldType === "JSONField") {
    detail = "object (JSON)";
  } else if (fieldType === "TypeDataField") {
    detail = "object";
  } else if (fieldType === "MappingField") {
    detail = "object";
  }
  const info = hint || (label !== fieldName ? label : "");
  const node = {
    type: nodeType,
    detail,
    info: info || void 0
  };
  if (field.fields && typeof field.fields === "object" && fieldType !== "MappingField") {
    const children = {};
    for (const [childName, childField] of Object.entries(field.fields)) {
      children[childName] = fieldToCompletionNode(childField, childName);
    }
    if (Object.keys(children).length > 0) {
      node.children = children;
    }
  }
  if (fieldType === "MappingField") {
    let innerChildren;
    const innerFields = field.model?.fields;
    if (innerFields && typeof innerFields === "object") {
      innerChildren = {};
      for (const [childName, childField] of Object.entries(innerFields)) {
        innerChildren[childName] = fieldToCompletionNode(childField, childName);
      }
      if (Object.keys(innerChildren).length === 0) innerChildren = void 0;
    }
    let keys;
    if (field.initialKeys) {
      if (Array.isArray(field.initialKeys)) {
        keys = field.initialKeys;
      } else if (typeof field.initialKeys === "object") {
        keys = Object.keys(field.initialKeys);
      }
    }
    if (keys && keys.length > 0) {
      const children = {};
      for (const key of keys) {
        const keyLabel = field.initialKeys?.[key]?.label ?? field.initialKeys?.[key] ?? key;
        const keyInfo = typeof keyLabel === "string" && keyLabel !== key ? keyLabel : void 0;
        children[key] = {
          type: "property",
          detail: innerChildren ? "object" : "any",
          info: keyInfo,
          children: innerChildren ? JSON.parse(JSON.stringify(innerChildren)) : void 0
        };
      }
      node.children = children;
    } else if (innerChildren) {
      node.children = innerChildren;
      node.info = (node.info || "") + " (keyed by ID)";
    }
  }
  return node;
}
__name(fieldToCompletionNode, "fieldToCompletionNode");
function schemaToCompletions(schema) {
  const result = {};
  if (!schema?.fields) return result;
  for (const [fieldName, field] of Object.entries(schema.fields)) {
    result[fieldName] = fieldToCompletionNode(field, fieldName);
  }
  return result;
}
__name(schemaToCompletions, "schemaToCompletions");
function mergeCompletions(target, additions) {
  if (!target.children) {
    target.children = {};
  }
  for (const [key, value] of Object.entries(additions)) {
    if (!(key in target.children)) {
      target.children[key] = value;
    } else {
      const existing = target.children[key];
      if (value.detail && existing.detail) {
        const existingIsWeak = existing.detail === "any" || existing.detail === "object" || existing.detail === "Promise<any>" || existing.detail === "any | null";
        const additionIsStrong = value.detail !== "any" && value.detail !== "object" && value.detail !== "Promise<any>" && value.detail !== "any | null";
        if (existingIsWeak && additionIsStrong) {
          existing.detail = value.detail;
        }
      }
      if (value.info && !existing.info) {
        existing.info = value.info;
      }
      if (value.constructorDetail && !existing.constructorDetail) {
        existing.constructorDetail = value.constructorDetail;
      }
      if (value.returnType && !existing.returnType) {
        existing.returnType = value.returnType;
      }
      if (value.children) {
        mergeCompletions(existing, value.children);
      }
    }
  }
}
__name(mergeCompletions, "mergeCompletions");
var _schemaInjected = false;
function injectSchemaCompletions() {
  if (_schemaInjected) return;
  const cfg = globalThis.CONFIG;
  if (!cfg) {
    console.log("macro-autocomplete | CONFIG not available, skipping schema injection");
    return;
  }
  const initStart = performance.now();
  console.log("macro-autocomplete | Injecting schema-generated completions from system DataModels");
  try {
    const actorDataModels = cfg.Actor?.dataModels;
    if (actorDataModels && typeof actorDataModels === "object" && COMPLETION_TREE.actor?.children?.system) {
      let count = 0;
      for (const [typeName, DataModel] of Object.entries(actorDataModels)) {
        if (DataModel?.schema) {
          const schemaCompletions = schemaToCompletions(DataModel.schema);
          mergeCompletions(COMPLETION_TREE.actor.children.system, schemaCompletions);
          if (COMPLETION_TREE.character?.children?.system) {
            mergeCompletions(COMPLETION_TREE.character.children.system, schemaCompletions);
          }
          count++;
        }
      }
      if (count > 0) {
        console.log(`macro-autocomplete | Injected actor system schema completions (${count} types)`);
      }
    }
    const itemDataModels = cfg.Item?.dataModels;
    if (itemDataModels && typeof itemDataModels === "object" && COMPLETION_TREE.item?.children?.system) {
      let count = 0;
      for (const [typeName, DataModel] of Object.entries(itemDataModels)) {
        if (DataModel?.schema) {
          const schemaCompletions = schemaToCompletions(DataModel.schema);
          mergeCompletions(COMPLETION_TREE.item.children.system, schemaCompletions);
          count++;
        }
      }
      if (count > 0) {
        console.log(`macro-autocomplete | Injected item system schema completions (${count} types)`);
      }
    }
    const documentSchemaTargets = [
      { configKey: "Actor", treeKeys: ["actor", "character"], label: "Actor" },
      { configKey: "Item", treeKeys: ["item"], label: "Item" }
    ];
    for (const { configKey, treeKeys, label } of documentSchemaTargets) {
      try {
        const docClass = cfg[configKey]?.documentClass;
        const schema = docClass?.schema;
        if (!schema) continue;
        const rootCompletions = schemaToCompletions(schema);
        delete rootCompletions.system;
        if (Object.keys(rootCompletions).length > 0) {
          for (const treeKey of treeKeys) {
            const target = COMPLETION_TREE[treeKey];
            if (target) {
              mergeCompletions(target, rootCompletions);
            }
          }
          console.log(`macro-autocomplete | Injected ${Object.keys(rootCompletions).length} root document properties for ${label}`);
        }
      } catch (err) {
        console.warn(`macro-autocomplete | Error walking ${label} document schema:`, err);
      }
    }
    try {
      const ActorCls = cfg.Actor?.documentClass;
      if (ActorCls && actorDataModels && COMPLETION_TREE.actor?.children?.system) {
        let count = 0;
        for (const typeName of Object.keys(actorDataModels)) {
          try {
            const temp = new ActorCls({ name: "_mac_tmp", type: typeName });
            if (temp.system) {
              const runtimeCompletions = objectToCompletions(temp.system, 4);
              mergeCompletions(COMPLETION_TREE.actor.children.system, runtimeCompletions);
              if (COMPLETION_TREE.character?.children?.system) {
                mergeCompletions(COMPLETION_TREE.character.children.system, runtimeCompletions);
              }
              count++;
            }
          } catch {
          }
        }
        if (count > 0) {
          console.log(`macro-autocomplete | Supplemented actor.system with derived data (${count} types)`);
        }
      }
      const ItemCls = cfg.Item?.documentClass;
      if (ItemCls && itemDataModels && COMPLETION_TREE.item?.children?.system) {
        let count = 0;
        for (const typeName of Object.keys(itemDataModels)) {
          try {
            const temp = new ItemCls({ name: "_mac_tmp", type: typeName });
            if (temp.system) {
              mergeCompletions(COMPLETION_TREE.item.children.system, objectToCompletions(temp.system, 4));
              count++;
            }
          } catch {
          }
        }
        if (count > 0) {
          console.log(`macro-autocomplete | Supplemented item.system with derived data (${count} types)`);
        }
      }
    } catch (err) {
      console.warn("macro-autocomplete | Error supplementing schema with derived data:", err);
    }
    _schemaInjected = true;
    injectGlobalCompletions();
    injectFoundryNamespaceCompletions();
    injectPrototypeCompletions();
    injectFoundryCompletions();
    injectConfigCompletions();
    rebuildSignatureMap();
    const api = {
      tree: COMPLETION_TREE,
      rebuildSignatureMap,
      schemaToCompletions,
      mergeCompletions,
      classToCompletions,
      objectToCompletions,
      valueToCompletionEntry,
      fieldToCompletionNode,
      setContextCompletions,
      clearContextCompletions
    };
    const mod = game.modules?.get("macro-autocomplete");
    if (mod) mod.api = api;
    Hooks.callAll("macro-autocomplete.ready", api);
    const elapsed = (performance.now() - initStart).toFixed(1);
    console.log(`macro-autocomplete | Initialization complete in ${elapsed}ms`);
  } catch (err) {
    console.error("macro-autocomplete | Error injecting schema completions:", err);
  }
}
__name(injectSchemaCompletions, "injectSchemaCompletions");
function injectFoundryCompletions() {
  if (!foundryCompletions_default || typeof foundryCompletions_default !== "object") {
    console.log("macro-autocomplete | foundryCompletions not available");
    return;
  }
  console.log("macro-autocomplete | Injecting fvtt-types generated completions");
  const instanceTargets = {
    Canvas: ["canvas"],
    Game: ["game"],
    ClientSettings: ["game.settings"],
    Localization: ["game.i18n"],
    Notifications: ["ui.notifications"],
    Actor: ["actor", "character"],
    Item: ["item"],
    Token: ["token"]
  };
  try {
    for (const [typeName, typeEntry] of Object.entries(foundryCompletions_default)) {
      const entry = typeEntry;
      const staticChildren = entry.staticChildren || {};
      const instanceChildren = entry.instanceChildren || {};
      const legacyChildren = entry.children || {};
      const hasNewFormat = entry.staticChildren || entry.instanceChildren;
      const classMembers = hasNewFormat ? staticChildren : legacyChildren;
      if (Object.keys(classMembers).length > 0) {
        if (!COMPLETION_TREE[typeName]) {
          COMPLETION_TREE[typeName] = { type: entry.type || "class", detail: entry.detail || typeName };
        }
        if (!COMPLETION_TREE[typeName].staticChildren) {
          COMPLETION_TREE[typeName].staticChildren = {};
        }
        mergeCompletions({ children: COMPLETION_TREE[typeName].staticChildren }, classMembers);
      }
      if (entry.constructorDetail) {
        if (!COMPLETION_TREE[typeName]) {
          COMPLETION_TREE[typeName] = { type: entry.type || "class", detail: entry.detail || typeName };
        }
        COMPLETION_TREE[typeName].constructorDetail = entry.constructorDetail;
      }
      if (Object.keys(instanceChildren).length > 0) {
        if (!COMPLETION_TREE[typeName]) {
          COMPLETION_TREE[typeName] = { type: entry.type || "class", detail: entry.detail || typeName };
        }
        if (!COMPLETION_TREE[typeName].instanceChildren) {
          COMPLETION_TREE[typeName].instanceChildren = {};
        }
        mergeCompletions({ children: COMPLETION_TREE[typeName].instanceChildren }, instanceChildren);
      }
      if (Object.keys(instanceChildren).length > 0) {
        const targets = [];
        if (entry.instancePath) targets.push(entry.instancePath);
        if (instanceTargets[typeName]) {
          for (const t of instanceTargets[typeName]) {
            if (!targets.includes(t)) targets.push(t);
          }
        }
        for (const targetPath of targets) {
          const parts = targetPath.split(".");
          let node = COMPLETION_TREE[parts[0]];
          for (let i = 1; i < parts.length && node; i++) {
            node = node.children?.[parts[i]];
          }
          if (node) {
            if (!node.instanceChildren) node.instanceChildren = {};
            mergeCompletions({ children: node.instanceChildren }, instanceChildren);
          }
        }
      }
    }
    console.log(`macro-autocomplete | Merged ${Object.keys(foundryCompletions_default).length} foundry type completions`);
  } catch (err) {
    console.error("macro-autocomplete | Error injecting foundry completions:", err);
  }
}
__name(injectFoundryCompletions, "injectFoundryCompletions");
function classToCompletions(cls) {
  const result = {
    staticChildren: {},
    instanceChildren: {}
  };
  if (!cls || typeof cls !== "function") return result;
  const staticSkipNames = /* @__PURE__ */ new Set([
    "name",
    "length",
    "prototype",
    "caller",
    "arguments",
    "toString",
    "valueOf",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "toLocaleString",
    "constructor"
  ]);
  const instanceSkipNames = /* @__PURE__ */ new Set([
    "constructor",
    "toString",
    "valueOf",
    "toJSON",
    "toLocaleString",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "then",
    "catch",
    "finally"
  ]);
  function extractMember(descriptor) {
    if (typeof descriptor.value === "function") {
      const fn = descriptor.value;
      const fnStr = fn.toString();
      const match = fnStr.match(/^(?:async\s+)?(?:function\s*\w*\s*)?(\([^)]*\))|^(?:async\s+)?(\([^)]*\))\s*=>|^(?:async\s+)?\w+\s*(\([^)]*\))/);
      const params = match ? match[1] || match[2] || match[3] || "()" : "()";
      const isAsync = fnStr.trimStart().startsWith("async");
      const returnHint = isAsync ? "Promise<any>" : "any";
      return { type: "method", detail: `${params} => ${returnHint}` };
    } else if (descriptor.get && !descriptor.set) {
      return { type: "property", detail: "any" };
    } else if (descriptor.get && descriptor.set) {
      return null;
    }
    return null;
  }
  __name(extractMember, "extractMember");
  let current = cls;
  while (current && current !== Function.prototype && current !== Object) {
    for (const name of Object.getOwnPropertyNames(current)) {
      if (name.startsWith("_") || name.startsWith("#")) continue;
      if (staticSkipNames.has(name)) continue;
      if (result.staticChildren[name]) continue;
      try {
        const descriptor = Object.getOwnPropertyDescriptor(current, name);
        if (!descriptor) continue;
        const entry = extractMember(descriptor);
        if (entry) result.staticChildren[name] = entry;
      } catch {
      }
    }
    current = Object.getPrototypeOf(current);
  }
  if (cls.prototype) {
    let proto = cls.prototype;
    while (proto && proto !== Object.prototype) {
      for (const name of Object.getOwnPropertyNames(proto)) {
        if (name.startsWith("_") || name.startsWith("#")) continue;
        if (instanceSkipNames.has(name)) continue;
        if (result.instanceChildren[name]) continue;
        try {
          const descriptor = Object.getOwnPropertyDescriptor(proto, name);
          if (!descriptor) continue;
          const entry = extractMember(descriptor);
          if (entry) result.instanceChildren[name] = entry;
        } catch {
        }
      }
      proto = Object.getPrototypeOf(proto);
    }
  }
  try {
    const ctorStr = cls.toString();
    const ctorMatch = ctorStr.match(/constructor\s*\(([^)]*)\)/);
    if (ctorMatch) {
      result.constructorDetail = `(${ctorMatch[1].trim()}) => ${cls.name || "object"}`;
    }
  } catch {
  }
  return result;
}
__name(classToCompletions, "classToCompletions");
function injectPrototypeCompletions() {
  const cfg = globalThis.CONFIG;
  if (!cfg) return;
  const classConfig = [
    { configPath: "Actor.documentClass", variableKeys: ["actor", "character"], classKey: "Actor", label: "Actor" },
    { configPath: "Item.documentClass", variableKeys: ["item"], classKey: "Item", label: "Item" },
    { configPath: "Token.objectClass", variableKeys: ["token"], classKey: "Token", label: "Token" },
    { configPath: "ChatMessage.documentClass", classKey: "ChatMessage", label: "ChatMessage" },
    { configPath: "ActiveEffect.documentClass", classKey: "ActiveEffect", label: "ActiveEffect" },
    { configPath: "Scene.documentClass", classKey: "Scene", label: "Scene" },
    { configPath: "Combat.documentClass", classKey: "Combat", label: "Combat" },
    { configPath: "Combatant.documentClass", classKey: "Combatant", label: "Combatant" },
    { configPath: "User.documentClass", classKey: "User", label: "User" },
    { configPath: "Folder.documentClass", classKey: "Folder", label: "Folder" },
    { configPath: "TokenDocument.documentClass", classKey: "TokenDocument", label: "TokenDocument" }
  ];
  for (const { configPath, variableKeys, classKey, label } of classConfig) {
    try {
      const parts = configPath.split(".");
      let cls = cfg;
      for (const p of parts) cls = cls?.[p];
      if (!cls?.prototype) continue;
      const walked = classToCompletions(cls);
      if (variableKeys) {
        for (const treeKey of variableKeys) {
          const target = COMPLETION_TREE[treeKey];
          if (!target) continue;
          if (!target.instanceChildren) target.instanceChildren = {};
          mergeCompletions({ children: target.instanceChildren }, walked.instanceChildren);
          console.log(`macro-autocomplete | Injected ${Object.keys(walked.instanceChildren).length} instance members for ${label} \u2192 ${treeKey}`);
        }
      }
      if (classKey) {
        const classEntry = COMPLETION_TREE[classKey];
        if (!classEntry) continue;
        if (Object.keys(walked.instanceChildren).length > 0) {
          if (!classEntry.instanceChildren) classEntry.instanceChildren = {};
          mergeCompletions({ children: classEntry.instanceChildren }, walked.instanceChildren);
        }
        if (Object.keys(walked.staticChildren).length > 0) {
          if (!classEntry.staticChildren) classEntry.staticChildren = {};
          mergeCompletions({ children: classEntry.staticChildren }, walked.staticChildren);
        }
        if (walked.constructorDetail && !classEntry.constructorDetail) {
          classEntry.constructorDetail = walked.constructorDetail;
        }
      }
    } catch (err) {
      console.warn(`macro-autocomplete | Error injecting prototype completions for ${label}:`, err);
    }
  }
  const g = globalThis;
  for (const className of ["Roll", "Dialog", "DialogV2"]) {
    try {
      const cls = g[className];
      if (!cls?.prototype) continue;
      if (!COMPLETION_TREE[className]) continue;
      const walked = classToCompletions(cls);
      const classEntry = COMPLETION_TREE[className];
      if (Object.keys(walked.instanceChildren).length > 0) {
        if (!classEntry.instanceChildren) classEntry.instanceChildren = {};
        mergeCompletions({ children: classEntry.instanceChildren }, walked.instanceChildren);
      }
      if (Object.keys(walked.staticChildren).length > 0) {
        if (!classEntry.staticChildren) classEntry.staticChildren = {};
        mergeCompletions({ children: classEntry.staticChildren }, walked.staticChildren);
      }
      if (walked.constructorDetail && !classEntry.constructorDetail) {
        classEntry.constructorDetail = walked.constructorDetail;
      }
    } catch {
    }
  }
  try {
    const ChatMsg = cfg.ChatMessage?.documentClass;
    if (ChatMsg?.getSpeaker) {
      const sample = ChatMsg.getSpeaker();
      if (sample && typeof sample === "object") {
        const speakerTarget = COMPLETION_TREE.speaker;
        if (speakerTarget) {
          if (!speakerTarget.children) speakerTarget.children = {};
          for (const [key, value] of Object.entries(sample)) {
            if (key.startsWith("_")) continue;
            const entry = valueToCompletionEntry(value, 0);
            if (entry) speakerTarget.children[key] = entry;
          }
          console.log(`macro-autocomplete | Injected ${Object.keys(speakerTarget.children).length} speaker fields from ChatMessage.getSpeaker()`);
        }
      }
    }
  } catch (err) {
    console.warn("macro-autocomplete | Error injecting speaker completions:", err);
  }
}
__name(injectPrototypeCompletions, "injectPrototypeCompletions");
function valueToCompletionEntry(value, maxDepth = 3) {
  if (value === null || value === void 0) return null;
  const type = typeof value;
  if (type === "function") {
    if (value.prototype && value.name && /^[A-Z]/.test(value.name)) {
      const entry = { type: "class", detail: `class ${value.name}`, info: value.name };
      if (maxDepth > 0) {
        const walked = classToCompletions(value);
        if (Object.keys(walked.staticChildren).length > 0) entry.staticChildren = walked.staticChildren;
        if (Object.keys(walked.instanceChildren).length > 0) entry.instanceChildren = walked.instanceChildren;
        if (walked.constructorDetail) entry.constructorDetail = walked.constructorDetail;
      }
      return entry;
    }
    const fnStr = value.toString();
    const match = fnStr.match(/^(?:function\s*\w*\s*)?(\([^)]*\))|^(\([^)]*\))\s*=>/);
    const params = match ? match[1] || match[2] : "()";
    return { type: "function", detail: `${params} => any`, info: value.name || "function" };
  }
  if (Array.isArray(value)) {
    return { type: "property", detail: `array[${value.length}]`, info: "Array" };
  }
  if (type === "object") {
    const entry = { type: "property", detail: "object" };
    if (maxDepth > 0) {
      const children = {};
      let count = 0;
      const maxChildren = 200;
      for (const key of Object.keys(value)) {
        if (count >= maxChildren) break;
        if (key.startsWith("_") || key.startsWith("#")) continue;
        try {
          const childValue = value[key];
          const childEntry = valueToCompletionEntry(childValue, maxDepth - 1);
          if (childEntry) {
            children[key] = childEntry;
            count++;
          }
        } catch {
        }
      }
      if (Object.keys(children).length > 0) {
        entry.children = children;
      }
    }
    return entry;
  }
  if (type === "string") {
    const preview = value.length > 50 ? value.substring(0, 50) + "..." : value;
    return { type: "property", detail: "string", info: `"${preview}"` };
  }
  if (type === "number") {
    return { type: "property", detail: "number", info: String(value) };
  }
  if (type === "boolean") {
    return { type: "property", detail: "boolean", info: String(value) };
  }
  return { type: "property", detail: type };
}
__name(valueToCompletionEntry, "valueToCompletionEntry");
function registerClassesFromNode(entry) {
  const walkNode = /* @__PURE__ */ __name((node) => {
    for (const [key, child] of Object.entries(node)) {
      if (child.type === "class" && /^[A-Z]/.test(key)) {
        if (!COMPLETION_TREE[key]) {
          COMPLETION_TREE[key] = child;
        } else {
          if (child.staticChildren) {
            if (!COMPLETION_TREE[key].staticChildren) COMPLETION_TREE[key].staticChildren = {};
            mergeCompletions({ children: COMPLETION_TREE[key].staticChildren }, child.staticChildren);
          }
          if (child.instanceChildren) {
            if (!COMPLETION_TREE[key].instanceChildren) COMPLETION_TREE[key].instanceChildren = {};
            mergeCompletions({ children: COMPLETION_TREE[key].instanceChildren }, child.instanceChildren);
          }
          if (child.constructorDetail && !COMPLETION_TREE[key].constructorDetail) {
            COMPLETION_TREE[key].constructorDetail = child.constructorDetail;
          }
        }
      }
      if (child.children) walkNode(child.children);
    }
  }, "walkNode");
  if (entry.children) walkNode(entry.children);
}
__name(registerClassesFromNode, "registerClassesFromNode");
function injectConfigCompletions() {
  const config = globalThis.CONFIG;
  if (!config || typeof config !== "object") {
    console.log("macro-autocomplete | CONFIG not available, skipping config injection");
    return;
  }
  console.log("macro-autocomplete | Injecting CONFIG completions");
  try {
    if (!COMPLETION_TREE.CONFIG) {
      COMPLETION_TREE.CONFIG = { type: "object", detail: "object", info: "Global Foundry configuration" };
    }
    if (!COMPLETION_TREE.CONFIG.children) {
      COMPLETION_TREE.CONFIG.children = {};
    }
    let count = 0;
    for (const key of Object.keys(config)) {
      if (key.startsWith("_")) continue;
      try {
        const value = config[key];
        const entry = valueToCompletionEntry(value, 3);
        if (entry) {
          COMPLETION_TREE.CONFIG.children[key] = entry;
          count++;
        }
      } catch {
      }
    }
    registerClassesFromNode(COMPLETION_TREE.CONFIG);
    console.log(`macro-autocomplete | Injected ${count} CONFIG entries`);
  } catch (err) {
    console.error("macro-autocomplete | Error injecting config completions:", err);
  }
}
__name(injectConfigCompletions, "injectConfigCompletions");
function objectToCompletions(obj, maxDepth = 2) {
  const children = {};
  if (!obj || typeof obj !== "object") return children;
  const skipNames = /* @__PURE__ */ new Set([
    "constructor",
    "toString",
    "valueOf",
    "toJSON",
    "toLocaleString",
    "hasOwnProperty",
    "isPrototypeOf",
    "propertyIsEnumerable",
    "then",
    "catch",
    "finally"
  ]);
  const maxChildren = 200;
  let count = 0;
  for (const key of Object.keys(obj)) {
    if (count >= maxChildren) break;
    if (key.startsWith("_") || key.startsWith("#")) continue;
    if (skipNames.has(key)) continue;
    if (children[key]) continue;
    try {
      const value = obj[key];
      if (value === null || value === void 0) {
        children[key] = { type: "property", detail: "any" };
        count++;
        continue;
      }
      const vType = typeof value;
      if (vType === "function") {
        if (value.prototype && /^[A-Z]/.test(key)) {
          const entry = { type: "class", detail: `class ${key}`, info: key };
          if (maxDepth > 0) {
            const walked = classToCompletions(value);
            if (Object.keys(walked.staticChildren).length > 0) entry.staticChildren = walked.staticChildren;
            if (Object.keys(walked.instanceChildren).length > 0) entry.instanceChildren = walked.instanceChildren;
            if (walked.constructorDetail) entry.constructorDetail = walked.constructorDetail;
          }
          children[key] = entry;
        } else {
          const fnStr = value.toString();
          const match = fnStr.match(/^(?:async\s+)?(?:function\s*\w*\s*)?(\([^)]*\))|^(?:async\s+)?(\([^)]*\))\s*=>|^(?:async\s+)?\w+\s*(\([^)]*\))/);
          const params = match ? match[1] || match[2] || match[3] || "()" : "()";
          const isAsync = fnStr.trimStart().startsWith("async");
          const returnHint = isAsync ? "Promise<any>" : "any";
          children[key] = { type: "function", detail: `${params} => ${returnHint}` };
        }
      } else if (vType === "object") {
        if (Array.isArray(value)) {
          children[key] = { type: "property", detail: `array[${value.length}]` };
        } else if (maxDepth > 0) {
          const subChildren = objectToCompletions(value, maxDepth - 1);
          const entry = {
            type: "property",
            detail: value.constructor?.name || "object"
          };
          if (Object.keys(subChildren).length > 0) entry.children = subChildren;
          children[key] = entry;
        } else {
          children[key] = { type: "property", detail: value.constructor?.name || "object" };
        }
      } else if (vType === "string") {
        children[key] = { type: "property", detail: "string" };
      } else if (vType === "number") {
        children[key] = { type: "property", detail: "number", info: String(value) };
      } else if (vType === "boolean") {
        children[key] = { type: "property", detail: "boolean" };
      }
      count++;
    } catch {
    }
  }
  let proto = Object.getPrototypeOf(obj);
  while (proto && proto !== Object.prototype) {
    for (const name of Object.getOwnPropertyNames(proto)) {
      if (count >= maxChildren) break;
      if (name.startsWith("_") || name.startsWith("#")) continue;
      if (skipNames.has(name)) continue;
      if (children[name]) continue;
      try {
        const descriptor = Object.getOwnPropertyDescriptor(proto, name);
        if (!descriptor) continue;
        if (typeof descriptor.value === "function") {
          const fn = descriptor.value;
          const fnStr = fn.toString();
          const match = fnStr.match(/^(?:async\s+)?(?:function\s*\w*\s*)?(\([^)]*\))|^(?:async\s+)?(\([^)]*\))\s*=>|^(?:async\s+)?\w+\s*(\([^)]*\))/);
          const params = match ? match[1] || match[2] || match[3] || "()" : "()";
          const isAsync = fnStr.trimStart().startsWith("async");
          const returnHint = isAsync ? "Promise<any>" : "any";
          children[name] = { type: "method", detail: `${params} => ${returnHint}` };
          count++;
        } else if (descriptor.get && !descriptor.set) {
          children[name] = { type: "property", detail: "any" };
          count++;
        } else if (descriptor.get && descriptor.set) {
          continue;
        }
      } catch {
      }
    }
    proto = Object.getPrototypeOf(proto);
  }
  return children;
}
__name(objectToCompletions, "objectToCompletions");
function injectGlobalCompletions() {
  const g = globalThis;
  if (g.foundry?.utils) {
    const utilsNode = COMPLETION_TREE.foundry?.children?.utils;
    if (utilsNode) {
      const utils = objectToCompletions(g.foundry.utils, 1);
      mergeCompletions(utilsNode, utils);
      console.log(`macro-autocomplete | Injected ${Object.keys(utils).length} foundry.utils members`);
    }
  }
  if (g.game) {
    if (!COMPLETION_TREE.game) {
      COMPLETION_TREE.game = { type: "object", detail: "Game", info: "The active Game instance" };
    }
    const gameMembers = objectToCompletions(g.game, 2);
    mergeCompletions(COMPLETION_TREE.game, gameMembers);
    console.log(`macro-autocomplete | Injected ${Object.keys(gameMembers).length} game members`);
  }
  if (g.canvas) {
    if (!COMPLETION_TREE.canvas) {
      COMPLETION_TREE.canvas = { type: "object", detail: "Canvas", info: "The game canvas" };
    }
    const canvasMembers = objectToCompletions(g.canvas, 2);
    mergeCompletions(COMPLETION_TREE.canvas, canvasMembers);
    console.log(`macro-autocomplete | Injected ${Object.keys(canvasMembers).length} canvas members`);
  }
  if (g.ui) {
    if (!COMPLETION_TREE.ui) {
      COMPLETION_TREE.ui = { type: "object", detail: "object", info: "Foundry UI singletons" };
    }
    const uiMembers = objectToCompletions(g.ui, 2);
    mergeCompletions(COMPLETION_TREE.ui, uiMembers);
    console.log(`macro-autocomplete | Injected ${Object.keys(uiMembers).length} ui members`);
  }
  if (g.Hooks && typeof g.Hooks === "function") {
    if (!COMPLETION_TREE.Hooks) {
      COMPLETION_TREE.Hooks = { type: "class", detail: "class Hooks", info: "Event hooks manager" };
    }
    const hooksWalked = classToCompletions(g.Hooks);
    if (!COMPLETION_TREE.Hooks.staticChildren) COMPLETION_TREE.Hooks.staticChildren = {};
    mergeCompletions({ children: COMPLETION_TREE.Hooks.staticChildren }, hooksWalked.staticChildren);
    console.log(`macro-autocomplete | Injected ${Object.keys(hooksWalked.staticChildren).length} Hooks static members`);
  }
  if (g.CONST) {
    if (!COMPLETION_TREE.CONST) {
      COMPLETION_TREE.CONST = { type: "object", detail: "object", info: "Foundry constants" };
    }
    const constMembers = objectToCompletions(g.CONST, 2);
    mergeCompletions(COMPLETION_TREE.CONST, constMembers);
    console.log(`macro-autocomplete | Injected ${Object.keys(constMembers).length} CONST members`);
  }
  for (const fnName of ["fromUuid", "fromUuidSync"]) {
    if (typeof g[fnName] === "function" && !COMPLETION_TREE[fnName]) {
      const fn = g[fnName];
      const fnStr = fn.toString();
      const match = fnStr.match(/^(?:async\s+)?(?:function\s*\w*\s*)?(\([^)]*\))|^(?:async\s+)?(\([^)]*\))\s*=>|^(?:async\s+)?\w+\s*(\([^)]*\))/);
      const params = match ? match[1] || match[2] || match[3] || "()" : "()";
      const isAsync = fnStr.trimStart().startsWith("async");
      const returnHint = isAsync ? "Promise<Document>" : "Document | null";
      COMPLETION_TREE[fnName] = { type: "function", detail: `${params} => ${returnHint}`, info: `Resolve a UUID to a document${isAsync ? " (async)" : " (sync)"}` };
    }
  }
  for (const className of ["Dialog", "Roll", "ChatMessage"]) {
    if (typeof g[className] === "function") {
      if (!COMPLETION_TREE[className]) {
        COMPLETION_TREE[className] = { type: "class", detail: `class ${className}`, info: className };
      }
      const walked = classToCompletions(g[className]);
      if (Object.keys(walked.staticChildren).length > 0) {
        if (!COMPLETION_TREE[className].staticChildren) COMPLETION_TREE[className].staticChildren = {};
        mergeCompletions({ children: COMPLETION_TREE[className].staticChildren }, walked.staticChildren);
      }
      if (Object.keys(walked.instanceChildren).length > 0) {
        if (!COMPLETION_TREE[className].instanceChildren) COMPLETION_TREE[className].instanceChildren = {};
        mergeCompletions({ children: COMPLETION_TREE[className].instanceChildren }, walked.instanceChildren);
      }
    }
  }
  if (g.game?.system?.id) {
    const systemId = g.game.system.id;
    const systemGlobal = g[systemId];
    if (systemGlobal && typeof systemGlobal === "object") {
      if (!COMPLETION_TREE[systemId]) {
        COMPLETION_TREE[systemId] = { type: "object", detail: "object", info: `${systemId} system namespace` };
      }
      const systemMembers = objectToCompletions(systemGlobal, 2);
      mergeCompletions(COMPLETION_TREE[systemId], systemMembers);
      console.log(`macro-autocomplete | Injected ${Object.keys(systemMembers).length} ${systemId} system members`);
    }
  }
}
__name(injectGlobalCompletions, "injectGlobalCompletions");
function walkNamespaceToTree(ns, parentNode, addTopLevel = true) {
  let classCount = 0;
  for (const key of Object.keys(ns)) {
    if (key.startsWith("_")) continue;
    try {
      const value = ns[key];
      if (typeof value === "function" && value.prototype) {
        const walked = classToCompletions(value);
        const entry = {
          type: "class",
          detail: `class ${key}`,
          info: key
        };
        if (walked.constructorDetail) {
          entry.constructorDetail = walked.constructorDetail;
        }
        if (Object.keys(walked.staticChildren).length > 0) {
          entry.staticChildren = walked.staticChildren;
        }
        if (Object.keys(walked.instanceChildren).length > 0) {
          entry.instanceChildren = walked.instanceChildren;
        }
        parentNode[key] = entry;
        if (addTopLevel && !key.startsWith("Base")) {
          if (COMPLETION_TREE[key]) {
            if (Object.keys(walked.staticChildren).length > 0) {
              if (!COMPLETION_TREE[key].staticChildren) COMPLETION_TREE[key].staticChildren = {};
              mergeCompletions({ children: COMPLETION_TREE[key].staticChildren }, walked.staticChildren);
            }
            if (Object.keys(walked.instanceChildren).length > 0) {
              if (!COMPLETION_TREE[key].instanceChildren) COMPLETION_TREE[key].instanceChildren = {};
              mergeCompletions({ children: COMPLETION_TREE[key].instanceChildren }, walked.instanceChildren);
            }
            if (entry.constructorDetail && !COMPLETION_TREE[key].constructorDetail) {
              COMPLETION_TREE[key].constructorDetail = entry.constructorDetail;
            }
          } else {
            COMPLETION_TREE[key] = { ...entry };
          }
        }
        classCount++;
      } else if (value && typeof value === "object" && !Array.isArray(value)) {
        const subEntry = {
          type: "object",
          detail: "object",
          info: key
        };
        subEntry.children = {};
        classCount += walkNamespaceToTree(value, subEntry.children, addTopLevel);
        if (Object.keys(subEntry.children).length > 0) {
          parentNode[key] = subEntry;
        }
      }
    } catch {
    }
  }
  return classCount;
}
__name(walkNamespaceToTree, "walkNamespaceToTree");
function injectFoundryNamespaceCompletions() {
  const foundryNS = globalThis.foundry;
  if (!foundryNS || typeof foundryNS !== "object") {
    console.log("macro-autocomplete | foundry namespace not available, skipping");
    return;
  }
  if (!COMPLETION_TREE.foundry) {
    COMPLETION_TREE.foundry = { type: "object", detail: "object", info: "Foundry VTT core namespace" };
  }
  if (!COMPLETION_TREE.foundry.children) {
    COMPLETION_TREE.foundry.children = {};
  }
  const namespacesToWalk = ["documents", "applications"];
  let totalClasses = 0;
  for (const nsName of namespacesToWalk) {
    const ns = foundryNS[nsName];
    if (!ns || typeof ns !== "object") continue;
    if (!COMPLETION_TREE.foundry.children[nsName]) {
      COMPLETION_TREE.foundry.children[nsName] = {
        type: "object",
        detail: "object",
        info: `Foundry ${nsName}`
      };
    }
    if (!COMPLETION_TREE.foundry.children[nsName].children) {
      COMPLETION_TREE.foundry.children[nsName].children = {};
    }
    const count = walkNamespaceToTree(ns, COMPLETION_TREE.foundry.children[nsName].children);
    totalClasses += count;
    console.log(`macro-autocomplete | Injected ${count} foundry.${nsName} class entries`);
  }
  console.log(`macro-autocomplete | Total foundry namespace classes: ${totalClasses}`);
}
__name(injectFoundryNamespaceCompletions, "injectFoundryNamespaceCompletions");
var SIGNATURE_MAP = /* @__PURE__ */ new Map();
function buildSignatureMap(node, prefix) {
  for (const [key, entry] of Object.entries(node)) {
    const fullPath = prefix ? `${prefix}.${key}` : key;
    if ((entry.type === "function" || entry.type === "method") && entry.detail) {
      const match = entry.detail.match(/^\(([^)]*)\)/);
      if (match) {
        const params = match[1].split(",").map((p) => p.trim()).filter((p) => p.length > 0);
        SIGNATURE_MAP.set(fullPath, { params, info: entry.info ?? "" });
      }
    }
    if (entry.type === "class" && entry.constructorDetail) {
      const match = entry.constructorDetail.match(/^\(([^)]*)\)/);
      if (match) {
        const params = match[1].split(",").map((p) => p.trim()).filter((p) => p.length > 0);
        SIGNATURE_MAP.set(`new ${fullPath}`, { params, info: entry.info ?? "" });
      }
    }
    if (entry.children) {
      buildSignatureMap(entry.children, fullPath);
    }
    if (entry.staticChildren) {
      buildSignatureMap(entry.staticChildren, fullPath);
    }
    if (entry.instanceChildren) {
      buildSignatureMap(entry.instanceChildren, fullPath);
    }
  }
}
__name(buildSignatureMap, "buildSignatureMap");
function rebuildSignatureMap() {
  SIGNATURE_MAP.clear();
  buildSignatureMap(COMPLETION_TREE, "");
}
__name(rebuildSignatureMap, "rebuildSignatureMap");
buildSignatureMap(COMPLETION_TREE, "");
var activeTooltip = null;
var activeTooltipView = null;
function createTooltipElement() {
  const el = document.createElement("div");
  el.className = "macro-autocomplete-signature-hint";
  el.style.cssText = `
    position: fixed;
    z-index: 10000;
    background: var(--color-cool-5, #1a1a2e);
    color: var(--color-light-2, #ddd);
    border: 1px solid var(--color-cool-3, #444);
    border-radius: 4px;
    padding: 4px 8px;
    font-family: var(--font-mono, monospace);
    font-size: 12px;
    line-height: 1.4;
    pointer-events: none;
    white-space: nowrap;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4);
  `;
  document.body.appendChild(el);
  return el;
}
__name(createTooltipElement, "createTooltipElement");
function hideSignatureTooltip() {
  if (activeTooltip) {
    activeTooltip.remove();
    activeTooltip = null;
    activeTooltipView = null;
  }
}
__name(hideSignatureTooltip, "hideSignatureTooltip");
function renderSignatureTooltip(sig, paramIndex, funcName) {
  const parts = sig.params.map((p, i) => {
    if (i === paramIndex) {
      return `<b style="color: var(--color-warm-2, #f0c040);">${p}</b>`;
    }
    return p;
  });
  return `<span style="color: var(--color-light-4, #999);">${funcName}</span>(${parts.join(", ")})`;
}
__name(renderSignatureTooltip, "renderSignatureTooltip");
function getSignatureContext(docText, cursorPos) {
  let depth = 0;
  let openParenPos = -1;
  for (let i = cursorPos - 1; i >= 0; i--) {
    const ch = docText[i];
    if (ch === ")") depth++;
    else if (ch === "(") {
      if (depth === 0) {
        openParenPos = i;
        break;
      }
      depth--;
    }
  }
  if (openParenPos < 0) return null;
  const before = docText.substring(0, openParenPos);
  const match = before.match(/([\w.]+)$/);
  if (!match) return null;
  let funcPath = match[1];
  const preIdentifier = before.substring(0, match.index).trimEnd();
  if (preIdentifier.endsWith("new")) {
    funcPath = `new ${funcPath}`;
  }
  let paramIndex = 0;
  depth = 0;
  for (let i = openParenPos + 1; i < cursorPos; i++) {
    const ch = docText[i];
    if (ch === "(") depth++;
    else if (ch === ")") depth--;
    else if (ch === "," && depth === 0) paramIndex++;
  }
  return { funcPath, paramIndex };
}
__name(getSignatureContext, "getSignatureContext");
function updateSignatureHint(view) {
  const state = view.state;
  if (!state) return;
  const cursorPos = state.selection?.main?.head;
  if (cursorPos == null) return;
  const docText = state.doc?.toString();
  if (!docText) return;
  const ctx = getSignatureContext(docText, cursorPos);
  if (!ctx) {
    if (activeTooltipView === view) hideSignatureTooltip();
    return;
  }
  const sig = SIGNATURE_MAP.get(ctx.funcPath);
  if (!sig || sig.params.length === 0) {
    if (activeTooltipView === view) hideSignatureTooltip();
    return;
  }
  const paramIndex = Math.min(ctx.paramIndex, sig.params.length - 1);
  const coords = view.coordsAtPos?.(cursorPos);
  if (!coords) return;
  if (!activeTooltip) {
    activeTooltip = createTooltipElement();
  }
  activeTooltipView = view;
  activeTooltip.innerHTML = renderSignatureTooltip(sig, paramIndex, ctx.funcPath);
  activeTooltip.style.left = `${coords.left}px`;
  activeTooltip.style.top = `${coords.top - 24}px`;
}
__name(updateSignatureHint, "updateSignatureHint");
function getVisibleChildren(entry) {
  const result = {};
  if (entry.children) Object.assign(result, entry.children);
  if (entry.type === "class") {
    if (entry.staticChildren) Object.assign(result, entry.staticChildren);
  } else {
    if (entry.instanceChildren) Object.assign(result, entry.instanceChildren);
    if (entry.detail) {
      const typeName = entry.detail;
      if (/^[A-Z]\w*$/.test(typeName)) {
        const classEntry = COMPLETION_TREE[typeName];
        if (classEntry?.instanceChildren) {
          for (const [k, v] of Object.entries(classEntry.instanceChildren)) {
            if (!result[k]) result[k] = v;
          }
        }
      }
    }
  }
  return result;
}
__name(getVisibleChildren, "getVisibleChildren");
function getCompletionsForPath(segments, root) {
  let node = root ?? COMPLETION_TREE;
  for (const seg of segments) {
    const entry = node[seg];
    if (!entry) return null;
    const visible = getVisibleChildren(entry);
    if (Object.keys(visible).length === 0) return null;
    node = visible;
  }
  return node;
}
__name(getCompletionsForPath, "getCompletionsForPath");
function getEditorView(element) {
  if (element.view) return element.view;
  for (const selector of [".cm-editor", ".cm-content", ".cm-scroller"]) {
    const el = element.querySelector(selector);
    if (el?.cmView?.view) return el.cmView.view;
  }
  return null;
}
__name(getEditorView, "getEditorView");
function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
__name(escapeRegExp, "escapeRegExp");
function extractReturnType(detail) {
  if (!detail) return null;
  const arrowMatch = detail.match(/=>\s*(.+)$/);
  if (!arrowMatch) return null;
  let ret = arrowMatch[1].trim();
  const promiseMatch = ret.match(/^(?:Promise|MaybePromise)<(.+)>$/);
  if (promiseMatch) ret = promiseMatch[1].trim();
  ret = ret.replace(/\s*\|\s*(?:null|undefined|void)\b/g, "").trim();
  ret = ret.replace(/\.\w+/g, "").trim();
  ret = ret.replace(/<[^>]*>/g, "").trim();
  if (/^[A-Z]\w*$/.test(ret) && COMPLETION_TREE[ret]) return ret;
  return null;
}
__name(extractReturnType, "extractReturnType");
var FACTORY_METHOD_NAMES = /* @__PURE__ */ new Set([
  "create",
  "get",
  "build",
  "fromData",
  "fromJSON",
  "fromDropData",
  "fromImport",
  "fromSource",
  "fromTerms",
  "createDialog"
]);
function getInstanceCompletions(className) {
  const classEntry = COMPLETION_TREE[className];
  if (!classEntry) return null;
  if (classEntry.instanceChildren && Object.keys(classEntry.instanceChildren).length > 0) {
    return classEntry.instanceChildren;
  }
  return classEntry.children || null;
}
__name(getInstanceCompletions, "getInstanceCompletions");
function resolveMethodReturnType(methodEntry, methodName, classEntry, className) {
  if (methodEntry.returnType && COMPLETION_TREE[methodEntry.returnType]) {
    return methodEntry.returnType;
  }
  const parsed = extractReturnType(methodEntry.detail);
  if (parsed) return parsed;
  if (FACTORY_METHOD_NAMES.has(methodName) && classEntry.type === "class") {
    return className;
  }
  return null;
}
__name(resolveMethodReturnType, "resolveMethodReturnType");
function inferVariableCompletions(varName, docText) {
  const escaped = escapeRegExp(varName);
  const combined = new RegExp(
    // Pattern 1a: (const|let|var) x = [await] new ClassName
    `(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?new\\s+(\\w+)|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?new\\s+(\\w+)|(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?(\\w+)\\.(\\w+)\\s*\\(|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?(\\w+)\\.(\\w+)\\s*\\(|(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?(\\w+(?:\\.\\w+)*)(?!\\s*\\()|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?(\\w+(?:\\.\\w+)*)(?!\\s*\\()`,
    "m"
  );
  const m = docText.match(combined);
  if (!m) return null;
  const newClass = m[1] || m[2];
  if (newClass && COMPLETION_TREE[newClass]) {
    return getInstanceCompletions(newClass);
  }
  const className = m[3] || m[5];
  const methodName = m[4] || m[6];
  if (className && methodName) {
    const classEntry = COMPLETION_TREE[className];
    if (classEntry) {
      const visible = getVisibleChildren(classEntry);
      const methodEntry = visible[methodName];
      if (methodEntry) {
        const returnTypeName = resolveMethodReturnType(methodEntry, methodName, classEntry, className);
        if (returnTypeName) return getInstanceCompletions(returnTypeName);
      }
    }
  }
  const fullPath = m[7] || m[8];
  if (fullPath) {
    const segments = fullPath.split(".");
    let entry = COMPLETION_TREE[segments[0]];
    if (entry) {
      for (let i = 1; i < segments.length && entry; i++) {
        const visible = getVisibleChildren(entry);
        entry = visible[segments[i]];
      }
      if (entry) {
        const result = getVisibleChildren(entry);
        if (Object.keys(result).length > 0) return result;
      }
    }
  }
  return null;
}
__name(inferVariableCompletions, "inferVariableCompletions");
function macroCompletionSourceWithContext(context, extraCompletions) {
  const word = context.matchBefore(/[\w.]+/);
  if (!word && !context.explicit) return null;
  const fullText = word?.text ?? "";
  const parts = fullText.split(".");
  const currentSegment = parts.pop() ?? "";
  const pathSegments = parts;
  const effectiveRoot = extraCompletions ? { ...COMPLETION_TREE, ...extraCompletions } : COMPLETION_TREE;
  let node;
  if (pathSegments.length === 0) {
    node = effectiveRoot;
  } else {
    const found = getCompletionsForPath(pathSegments, effectiveRoot);
    if (found) {
      node = found;
    } else if (pathSegments.length >= 1 && !effectiveRoot[pathSegments[0]]) {
      const docText = context.state.doc.toString();
      const inferred = inferVariableCompletions(pathSegments[0], docText);
      if (inferred) {
        let current = inferred;
        for (let i = 1; i < pathSegments.length && current; i++) {
          const entry = current[pathSegments[i]];
          if (entry) {
            const visible = getVisibleChildren(entry);
            current = Object.keys(visible).length > 0 ? visible : null;
          } else {
            current = null;
          }
        }
        if (current) {
          node = current;
        } else {
          return null;
        }
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  const options = Object.entries(node).filter(([key]) => key.toLowerCase().startsWith(currentSegment.toLowerCase())).map(([key, entry]) => {
    const hasChildren = !!(entry.children || entry.staticChildren || entry.instanceChildren);
    return {
      label: key,
      type: entry.type ?? (hasChildren ? "namespace" : "property"),
      detail: entry.detail ?? (hasChildren ? "..." : void 0),
      info: entry.info,
      boost: hasChildren ? 1 : 0
    };
  });
  if (options.length === 0) return null;
  const from = word ? word.from + (fullText.length - currentSegment.length) : context.pos;
  return { from, options };
}
__name(macroCompletionSourceWithContext, "macroCompletionSourceWithContext");
var _appendConfig = null;
var _languageData = null;
var _updateListener = null;
var _internalsResolved = false;
function tryAcceptCompletion(view) {
  const tooltip = view.dom?.querySelector(".cm-tooltip-autocomplete");
  if (!tooltip) return false;
  const enterEvent = new KeyboardEvent("keydown", {
    key: "Enter",
    code: "Enter",
    keyCode: 13,
    which: 13,
    bubbles: true,
    cancelable: true
  });
  view.contentDOM.dispatchEvent(enterEvent);
  return true;
}
__name(tryAcceptCompletion, "tryAcceptCompletion");
function resolveInternals(view) {
  if (_internalsResolved) return !!_appendConfig;
  try {
    const ViewClass = view.constructor;
    if (typeof ViewClass.scrollIntoView === "function") {
      const effect = ViewClass.scrollIntoView(0);
      const StateEffect = effect?.constructor;
      if (StateEffect) {
        _appendConfig = StateEffect.appendConfig;
      }
    }
    if (ViewClass.updateListener) {
      _updateListener = ViewClass.updateListener;
    }
    const StateClass = view.state?.constructor;
    if (StateClass?.languageData) {
      _languageData = StateClass.languageData;
    }
  } catch (err) {
    console.error("macro-autocomplete | Error resolving CodeMirror internals:", err);
  }
  _internalsResolved = true;
  return !!_appendConfig && !!_languageData;
}
__name(resolveInternals, "resolveInternals");
var elementContextCompletions = /* @__PURE__ */ new WeakMap();
function setContextCompletions(element, completions) {
  elementContextCompletions.set(element, completions);
}
__name(setContextCompletions, "setContextCompletions");
function clearContextCompletions(element) {
  elementContextCompletions.delete(element);
}
__name(clearContextCompletions, "clearContextCompletions");
var enhancedElements = /* @__PURE__ */ new WeakSet();
var _textLinePatched = false;
function patchTextLine(view) {
  if (_textLinePatched) return;
  const TextClass = view.state.doc.constructor;
  if (!TextClass?.prototype?.line) return;
  const origLine = TextClass.prototype.line;
  TextClass.prototype.line = function(n) {
    if (n < 1) n = 1;
    else if (n > this.lines) n = this.lines;
    return origLine.call(this, n);
  };
  _textLinePatched = true;
}
__name(patchTextLine, "patchTextLine");
async function enhanceCodeMirror(element) {
  if (enhancedElements.has(element)) return;
  await new Promise((resolve) => setTimeout(resolve, 200));
  const view = getEditorView(element);
  if (!view) {
    console.warn("macro-autocomplete | Could not access CodeMirror EditorView");
    return;
  }
  patchTextLine(view);
  enhancedElements.add(element);
  const ready = resolveInternals(view);
  if (!ready) {
    console.warn("macro-autocomplete | Could not resolve CodeMirror internals - autocompletion not available");
    return;
  }
  try {
    const extensions = [];
    const elementCompletionSource = /* @__PURE__ */ __name((context) => {
      const extra = elementContextCompletions.get(element);
      return macroCompletionSourceWithContext(context, extra);
    }, "elementCompletionSource");
    extensions.push(
      _languageData.of(() => [{ autocomplete: elementCompletionSource }])
    );
    if (_updateListener) {
      extensions.push(
        _updateListener.of((update) => {
          if (update.docChanged || update.selectionSet) {
            updateSignatureHint(update.view);
          }
        })
      );
    }
    view.dispatch({
      effects: _appendConfig.of(extensions)
    });
    view.contentDOM.addEventListener("keydown", (event) => {
      if (event.key === "Tab" && !event.shiftKey) {
        if (tryAcceptCompletion(view)) {
          event.preventDefault();
          event.stopPropagation();
        }
      }
    }, true);
    console.log("macro-autocomplete | Injected autocompletions with Tab completion");
  } catch (err) {
    console.error("macro-autocomplete | Error injecting completions:", err);
  }
}
__name(enhanceCodeMirror, "enhanceCodeMirror");
function initMacroAutoComplete() {
  if (typeof window === "undefined" || typeof document === "undefined") return;
  console.log("macro-autocomplete | Initializing macro autocompletion");
  injectSchemaCompletions();
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of Array.from(mutation.addedNodes)) {
        if (node instanceof HTMLElement) {
          const codeMirrors = node.tagName === "CODE-MIRROR" ? [node] : Array.from(node.querySelectorAll("code-mirror"));
          for (const cm of codeMirrors) {
            if (cm.getAttribute("language") === "javascript") {
              enhanceCodeMirror(cm);
            }
          }
        }
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
  document.querySelectorAll('code-mirror[language="javascript"]').forEach((cm) => {
    enhanceCodeMirror(cm);
  });
}
__name(initMacroAutoComplete, "initMacroAutoComplete");
Hooks.once("ready", () => initMacroAutoComplete());
//# sourceMappingURL=macro-autocomplete.js.map
