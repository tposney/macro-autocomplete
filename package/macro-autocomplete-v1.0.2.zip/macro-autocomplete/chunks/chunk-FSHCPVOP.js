var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/blockly/blocklyConfig.ts
var colourMap = {
  // Foundry core
  game: 210,
  canvas: 180,
  ui: 160,
  Hooks: 290,
  CONST: 60,
  foundry: 200,
  CONFIG: 45,
  // Document classes
  Actor: 120,
  Item: 140,
  ChatMessage: 260,
  Roll: 330,
  Dialog: 300,
  Token: 100,
  Scene: 80,
  // Macro variables
  actor: 120,
  target: 290,
  token: 100,
  item: 140,
  speaker: 260,
  character: 120,
  args: 30,
  scope: 30,
  // dnd5e
  dnd5e: 150
};
function getColourForPath(path) {
  const root = path.split(".")[0];
  return colourMap[root] ?? 230;
}
__name(getColourForPath, "getColourForPath");
function registerBlockColours(colours) {
  Object.assign(colourMap, colours);
}
__name(registerBlockColours, "registerBlockColours");
var scopeMergeKeys = [];
function getScopeMergeKeys() {
  return scopeMergeKeys;
}
__name(getScopeMergeKeys, "getScopeMergeKeys");
function registerScopeMergeKeys(keys) {
  for (const key of keys) {
    if (!scopeMergeKeys.includes(key)) scopeMergeKeys.push(key);
  }
}
__name(registerScopeMergeKeys, "registerScopeMergeKeys");
var CATEGORY_CONFIG = {
  // Programming constructs
  _logic: { display: "Logic", colour: "#5b80a5", order: 0 },
  _variables: { display: "Variables", colour: "#a55b99", order: 1 },
  _control: { display: "Control Flow", colour: "#5ba580", order: 2 },
  _text: { display: "Text", colour: "#5ba55b", order: 3 },
  _util: { display: "Utilities", colour: "#a5805b", order: 4 },
  // Macro context (lowercase — these are variables available in macro scope)
  character: { display: "character", colour: "#457b9d", order: 11 },
  speaker: { display: "speaker", colour: "#9b59b6", order: 12 },
  actor: { display: "actor", colour: "#457b9d", order: 14 },
  token: { display: "token", colour: "#2a9d8f", order: 15 },
  _token: { display: "_token", colour: "#2a9d8f", order: 15 },
  item: { display: "item", colour: "#6a994e", order: 16 },
  args: { display: "args", colour: "#e9c46a", order: 21 },
  scope: { display: "scope", colour: "#e9c46a", order: 22 },
  // Foundry core (lowercase — these are globals)
  game: { display: "game", colour: "#457b9d", order: 40 },
  canvas: { display: "canvas", colour: "#2a9d8f", order: 41, namespaceOnly: true },
  ui: { display: "ui", colour: "#6a994e", order: 42 },
  Hooks: { display: "Hooks", colour: "#9b59b6", order: 43 },
  foundry: { display: "foundry", colour: "#457b9d", order: 44, namespaceOnly: true },
  CONFIG: { display: "CONFIG", colour: "#e9c46a", order: 45 },
  CONST: { display: "Constants", colour: "#e9c46a", order: 46 },
  // Document classes
  ChatMessage: { display: "Chat Messages", colour: "#9b59b6", order: 50 },
  Roll: { display: "Rolls", colour: "#e74c3c", order: 51 },
  Dialog: { display: "Dialogs", colour: "#8e44ad", order: 52 },
  Actor: { display: "Actor Class", colour: "#457b9d", order: 53 },
  Item: { display: "Item Class", colour: "#6a994e", order: 54 },
  // dnd5e
  dnd5e: { display: "dnd5e System", colour: "#2a9d8f", order: 60 }
};
function getCategoryConfig(key) {
  return CATEGORY_CONFIG[key];
}
__name(getCategoryConfig, "getCategoryConfig");
function getAllCategoryConfigs() {
  return CATEGORY_CONFIG;
}
__name(getAllCategoryConfigs, "getAllCategoryConfigs");
function registerCategoryConfigs(configs) {
  Object.assign(CATEGORY_CONFIG, configs);
}
__name(registerCategoryConfigs, "registerCategoryConfigs");
function isNamespaceOnly(rootKey) {
  return CATEGORY_CONFIG[rootKey]?.namespaceOnly === true;
}
__name(isNamespaceOnly, "isNamespaceOnly");

// src/completionResolver.ts
var tree = null;
function setCompletionTree(t) {
  tree = t;
}
__name(setCompletionTree, "setCompletionTree");
function extractTypeName(detail) {
  const stripped = detail.replace(/^\(.*?\)\s*=>\s*/, "").replace(/\bPromise<(.+?)>/, "$1").replace(/\bSet<(.+?)>/, "$1").replace(/\bCollection<(.+?)>/, "$1").replace(/\bEmbeddedCollection<(.+?)>/, "$1").replace(/\bMap<[^,]+,\s*(.+?)>/, "$1").replace(/\[\]$/, "").replace(/\[["'][^"']*["']\]/g, "").replace(/\.Implementation/g, "").replace(/\.Stored/g, "").replace(/<[^>]*>/g, "").replace(/\s*\|.*$/, "").trim();
  const match = stripped.match(/^([A-Z][A-Za-z0-9]+(?:\.[A-Z][A-Za-z0-9]+)?)/);
  if (!match) return null;
  const name = match[1];
  if (tree?.[name]) return name;
  const base = name.replace(/5e$/, "");
  if (base !== name && tree?.[base]) return base;
  if (/^[A-Z]/.test(name)) return name;
  return null;
}
__name(extractTypeName, "extractTypeName");
function extractReturnType(detail) {
  if (!detail) return null;
  const arrowMatch = detail.match(/=>\s*(.+)$/);
  if (!arrowMatch) return null;
  let ret = arrowMatch[1].trim();
  const promiseMatch = ret.match(/^(?:Promise|MaybePromise)<(.+)>$/);
  if (promiseMatch) ret = promiseMatch[1].trim();
  ret = ret.replace(/\s*\|\s*(?:null|undefined|void)\b/g, "").trim();
  return extractTypeName(ret);
}
__name(extractReturnType, "extractReturnType");
function extractRawElementType(detail) {
  let m = detail.match(/^(?:Set|Collection|EmbeddedCollection|ActivityCollection)<(\w+)>/);
  if (m) return m[1];
  m = detail.match(/^Map<[^,]+,\s*(\w+)>/);
  if (m) return m[1];
  m = detail.match(/^(\w+)\[\]$/);
  if (m) return m[1];
  return null;
}
__name(extractRawElementType, "extractRawElementType");
function extractElementType(detail) {
  const rawType = extractRawElementType(detail);
  if (!rawType || !tree) return null;
  if (tree[rawType]) return rawType;
  if (tree[rawType + "5e"]) return rawType + "5e";
  if (rawType.endsWith("5e") && tree[rawType.slice(0, -2)]) return rawType.slice(0, -2);
  return null;
}
__name(extractElementType, "extractElementType");
function detailSpecificity(detail) {
  if (!detail || detail === "any" || detail === "object") return 0;
  if (detail === "string" || detail === "number" || detail === "boolean") return 1;
  if (/^\(.*\)\s*=>/.test(detail)) return 3;
  return 2;
}
__name(detailSpecificity, "detailSpecificity");
function mergeCompletions(target, additions) {
  if (!target.children) target.children = {};
  for (const [key, value] of Object.entries(additions)) {
    if (!(key in target.children)) {
      target.children[key] = value;
    } else {
      const existing = target.children[key];
      if (value.detail && existing.detail) {
        const existingSpec = detailSpecificity(existing.detail);
        const additionSpec = detailSpecificity(value.detail);
        if (additionSpec > existingSpec) existing.detail = value.detail;
      } else if (value.detail && !existing.detail) {
        existing.detail = value.detail;
      }
      if (value.info && !existing.info) existing.info = value.info;
      if (value.constructorDetail && !existing.constructorDetail) {
        existing.constructorDetail = value.constructorDetail;
      }
      if (value.returnType && !existing.returnType) existing.returnType = value.returnType;
      if (value.children) mergeCompletions(existing, value.children);
    }
  }
}
__name(mergeCompletions, "mergeCompletions");
var COLLECTION_METHODS = {
  first: { type: "method", detail: "() => T | undefined", info: "Get the first element" },
  last: { type: "method", detail: "() => T | undefined", info: "Get the last element" },
  find: { type: "method", detail: "(predicate) => T | undefined", info: "Find the first element matching a predicate" },
  filter: { type: "method", detail: "(predicate) => T[]", info: "Filter elements matching a predicate" },
  map: { type: "method", detail: "(fn) => U[]", info: "Map elements to a new array" },
  some: { type: "method", detail: "(predicate) => boolean", info: "Test if any element matches a predicate" },
  every: { type: "method", detail: "(predicate) => boolean", info: "Test if all elements match a predicate" },
  reduce: { type: "method", detail: "(fn, initial) => U", info: "Reduce elements to a single value" },
  forEach: { type: "method", detail: "(callback) => void", info: "Execute a function for each element" },
  has: { type: "method", detail: "(value) => boolean", info: "Check if a value exists" },
  size: { type: "property", detail: "number", info: "Number of elements" },
  contents: { type: "property", detail: "T[]", info: "Array of elements" }
};
var COLLECTION_WRAPPER_RE = /\b(?:Set|Collection|Map)<.+?>/;
function resolveViaType(detail, _seen) {
  if (!tree) return null;
  const indexedMatch = detail.match(/^(\w+)\.Implementation\["(\w+)"\]/);
  if (indexedMatch) {
    const [, outerType, propName] = indexedMatch;
    const outerResolved = resolveViaType(outerType);
    if (outerResolved?.[propName]?.detail) {
      return resolveViaType(outerResolved[propName].detail);
    }
  }
  const typeName = extractTypeName(detail);
  if (!typeName) return null;
  const seen = _seen ?? /* @__PURE__ */ new Set();
  if (seen.has(typeName)) return null;
  seen.add(typeName);
  const namesToTry = [typeName];
  const baseName = typeName.replace(/5e$/, "");
  if (baseName !== typeName) namesToTry.push(baseName);
  const sources = [];
  for (const name of namesToTry) {
    const classEntry = tree[name];
    if (classEntry) {
      if (classEntry.instanceChildren && Object.keys(classEntry.instanceChildren).length > 0) {
        sources.push(classEntry.instanceChildren);
      }
      if (classEntry.children && Object.keys(classEntry.children).length > 0) {
        sources.push(classEntry.children);
      }
      if (classEntry.extends) {
        for (const parentType of classEntry.extends) {
          const parentChildren = resolveViaType(parentType, seen);
          if (parentChildren) sources.push(parentChildren);
        }
      }
    }
    if (!name.includes(".")) {
      const varName = name[0].toLowerCase() + name.slice(1);
      if (varName !== name) {
        const varEntry = tree[varName];
        if (varEntry) {
          if (varEntry.children && Object.keys(varEntry.children).length > 0) {
            sources.push(varEntry.children);
          }
          if (varEntry.instanceChildren && Object.keys(varEntry.instanceChildren).length > 0) {
            sources.push(varEntry.instanceChildren);
          }
        }
      }
    }
  }
  if (COLLECTION_WRAPPER_RE.test(detail)) {
    sources.push(COLLECTION_METHODS);
  }
  if (sources.length === 0) return null;
  if (sources.length === 1) return sources[0];
  return Object.assign({}, ...sources);
}
__name(resolveViaType, "resolveViaType");
function getVisibleChildren(entry) {
  const result = {};
  if (entry.children) Object.assign(result, entry.children);
  if (entry.type === "class") {
    if (entry.staticChildren) Object.assign(result, entry.staticChildren);
  } else {
    if (entry.instanceChildren) Object.assign(result, entry.instanceChildren);
    if (entry.children && entry.instanceChildren) {
      for (const [k, v] of Object.entries(entry.instanceChildren)) {
        if (result[k] && v.detail && detailSpecificity(v.detail) > detailSpecificity(result[k].detail ?? "")) {
          result[k] = { ...result[k], detail: v.detail };
          if (v.info && !result[k].info) result[k].info = v.info;
          if (v.extends) result[k].extends = v.extends;
        }
      }
    }
    if (entry.detail) {
      const resolved = resolveViaType(entry.detail);
      if (resolved) {
        for (const [k, v] of Object.entries(resolved)) {
          if (!result[k]) result[k] = v;
        }
      }
    }
  }
  return result;
}
__name(getVisibleChildren, "getVisibleChildren");
function getCompletionsForPath(segments, root) {
  let node = root ?? tree;
  if (!node) return null;
  for (const seg of segments) {
    const entry = node[seg];
    if (!entry) return null;
    const visible = getVisibleChildren(entry);
    if (Object.keys(visible).length === 0) return null;
    node = visible;
  }
  return node;
}
__name(getCompletionsForPath, "getCompletionsForPath");
function getInstanceCompletions(className) {
  if (!tree) return null;
  const classEntry = tree[className];
  if (!classEntry) return null;
  if (classEntry.instanceChildren && Object.keys(classEntry.instanceChildren).length > 0) {
    return classEntry.instanceChildren;
  }
  return classEntry.children || null;
}
__name(getInstanceCompletions, "getInstanceCompletions");
var FACTORY_METHOD_NAMES = /* @__PURE__ */ new Set([
  "create",
  "get",
  "build",
  "fromData",
  "fromJSON",
  "fromDropData",
  "fromImport",
  "fromSource",
  "fromTerms",
  "createDialog"
]);
function resolveMethodReturnType(methodEntry, methodName, classEntry, className) {
  if (methodEntry.returnType && tree?.[methodEntry.returnType]) return methodEntry.returnType;
  const parsed = extractReturnType(methodEntry.detail);
  if (parsed) return parsed;
  if (FACTORY_METHOD_NAMES.has(methodName) && classEntry.type === "class") return className;
  return null;
}
__name(resolveMethodReturnType, "resolveMethodReturnType");
function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
__name(escapeRegExp, "escapeRegExp");
function resolveIterableElementType(iterablePath) {
  if (!tree) return null;
  const segments = iterablePath.split(".");
  let entry = tree[segments[0]];
  if (!entry) return null;
  for (let i = 1; i < segments.length && entry; i++) {
    const visible = getVisibleChildren(entry);
    entry = visible[segments[i]];
  }
  if (!entry?.detail) return null;
  const elementType = extractElementType(entry.detail);
  if (elementType) return getInstanceCompletions(elementType);
  const rawType = extractRawElementType(entry.detail);
  if (rawType) {
    const lower = rawType.charAt(0).toLowerCase() + rawType.slice(1);
    const fallbackEntry = tree[rawType] ?? tree[lower];
    if (fallbackEntry) {
      const result = getVisibleChildren(fallbackEntry);
      if (Object.keys(result).length > 0) return result;
    }
  }
  return null;
}
__name(resolveIterableElementType, "resolveIterableElementType");
function inferVariableCompletions(varName, docText) {
  if (!tree) return null;
  const escaped = escapeRegExp(varName);
  const forOfRe = new RegExp(
    `for\\s*\\(\\s*(?:const|let|var)\\s+${escaped}\\s+of\\s+(\\w+(?:\\.\\w+)*)\\s*\\)`,
    "m"
  );
  const forOfMatch = docText.match(forOfRe);
  if (forOfMatch) {
    const result = resolveIterableElementType(forOfMatch[1]);
    if (result) return result;
  }
  const combined = new RegExp(
    `(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?new\\s+(\\w+)|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?new\\s+(\\w+)|(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?(\\w+)\\.(\\w+)\\s*\\(|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?(\\w+)\\.(\\w+)\\s*\\(|(?:const|let|var)\\s+${escaped}\\s*=\\s*(?:await\\s+)?(\\w+(?:\\.\\w+)*)(?!\\s*\\()|(?:^|[;\\n])\\s*${escaped}\\s*=\\s*(?:await\\s+)?(\\w+(?:\\.\\w+)*)(?!\\s*\\()`,
    "m"
  );
  const m = docText.match(combined);
  if (!m) return null;
  const newClass = m[1] || m[2];
  if (newClass && tree[newClass]) return getInstanceCompletions(newClass);
  const className = m[3] || m[5];
  const methodName = m[4] || m[6];
  if (className && methodName) {
    const classEntry = tree[className];
    if (classEntry) {
      const visible = getVisibleChildren(classEntry);
      const methodEntry = visible[methodName];
      if (methodEntry) {
        const returnTypeName = resolveMethodReturnType(methodEntry, methodName, classEntry, className);
        if (returnTypeName) return getInstanceCompletions(returnTypeName);
      }
    }
  }
  const fullPath = m[7] || m[8];
  if (fullPath) {
    const segments = fullPath.split(".");
    let entry = tree[segments[0]];
    if (entry) {
      for (let i = 1; i < segments.length && entry; i++) {
        const visible = getVisibleChildren(entry);
        entry = visible[segments[i]];
      }
      if (entry) {
        const result = getVisibleChildren(entry);
        if (Object.keys(result).length > 0) return result;
      }
    }
  }
  return null;
}
__name(inferVariableCompletions, "inferVariableCompletions");
function filteredKeys(node) {
  return Object.keys(node).filter((k) => !k.startsWith("_") && !k.startsWith("#")).sort((a, b) => {
    const aInherited = node[a].inherited ? 1 : 0;
    const bInherited = node[b].inherited ? 1 : 0;
    if (aInherited !== bInherited) return aInherited - bInherited;
    return a.localeCompare(b);
  });
}
__name(filteredKeys, "filteredKeys");

export {
  __name,
  __commonJS,
  __export,
  __toESM,
  getColourForPath,
  registerBlockColours,
  getScopeMergeKeys,
  registerScopeMergeKeys,
  getCategoryConfig,
  getAllCategoryConfigs,
  registerCategoryConfigs,
  isNamespaceOnly,
  setCompletionTree,
  extractTypeName,
  mergeCompletions,
  resolveViaType,
  getVisibleChildren,
  getCompletionsForPath,
  inferVariableCompletions,
  filteredKeys
};
//# sourceMappingURL=chunk-FSHCPVOP.js.map
